export const STATES = ['Lagos', 'Kano', 'Osun'] as const;

export const SPECIES = [
  'An. gambiae s.s.',
  'An. coluzzii',
  'An. arabiensis',
  'An. funestus',
] as const;

export const INSECTICIDES = [
  'Permethrin',
  'Deltamethrin',
  'Alphacypermethrin',
  'Pirimiphos-methyl',
] as const;

export const WARD_NUMBERS = [1, 2, 3, 4, 5, 6] as const;

export const NIGERIA = { latMin: 4, latMax: 14, lonMin: 2.5, lonMax: 15 };

export const STATE_BOXES = {
  Lagos: { latMin: 6.3, latMax: 6.8, lonMin: 2.7, lonMax: 4.4 },
  Kano: { latMin: 11.5, latMax: 12.6, lonMin: 8.0, lonMax: 9.2 },
  Osun: { latMin: 7.0, latMax: 8.2, lonMin: 4.0, lonMax: 5.0 },
} as const;

export interface LgaReference {
  state: string;
  lga: string;
  refLat: number;
  refLon: number;
}

export const LGA_REFERENCES: readonly LgaReference[] = [
  { state: 'Lagos', lga: 'Ikorodu', refLat: 6.62, refLon: 3.51 },
  { state: 'Lagos', lga: 'Alimosho', refLat: 6.6, refLon: 3.25 },
  { state: 'Lagos', lga: 'Epe', refLat: 6.58, refLon: 3.98 },
  { state: 'Lagos', lga: 'Badagry', refLat: 6.43, refLon: 2.88 },
  { state: 'Lagos', lga: 'Eti-Osa', refLat: 6.45, refLon: 3.6 },
  { state: 'Kano', lga: 'Dala', refLat: 12.0, refLon: 8.52 },
  { state: 'Kano', lga: 'Nasarawa', refLat: 12.0, refLon: 8.55 },
  { state: 'Kano', lga: 'Gwale', refLat: 11.98, refLon: 8.49 },
  { state: 'Kano', lga: 'Tarauni', refLat: 11.97, refLon: 8.54 },
  { state: 'Kano', lga: 'Ungogo', refLat: 12.05, refLon: 8.48 },
  { state: 'Osun', lga: 'Osogbo', refLat: 7.77, refLon: 4.56 },
  { state: 'Osun', lga: 'Ife Central', refLat: 7.48, refLon: 4.56 },
  { state: 'Osun', lga: 'Ilesa East', refLat: 7.62, refLon: 4.73 },
  { state: 'Osun', lga: 'Iwo', refLat: 7.63, refLon: 4.18 },
  { state: 'Osun', lga: 'Ede North', refLat: 7.74, refLon: 4.43 },
];

export function lgasFor(state: string | null): LgaReference[] {
  return LGA_REFERENCES.filter((row) => row.state === state);
}

export function wardsFor(lga: string | null): string[] {
  if (!lga) return [];
  return WARD_NUMBERS.map((n) => `${lga} Ward ${n}`);
}

export function lookupLga(state: string | null, lga: string | null): LgaReference | undefined {
  return LGA_REFERENCES.find((row) => row.state === state && row.lga === lga);
}

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const rad = Math.PI / 180;
  const a =
    Math.sin(((lat2 - lat1) * rad) / 2) ** 2 +
    Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(((lon2 - lon1) * rad) / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(a)));
}

export function todayString(now = new Date()): string {
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${now.getFullYear()}-${month}-${day}`;
}

export function mortalityPct(dead: number | null, exposed: number | null): number | null {
  if (dead === null || exposed === null || exposed <= 0) return null;
  return Math.round((1000 * dead) / exposed) / 10;
}

export function whoClass(mortality: number | null): string | null {
  if (mortality === null) return null;
  if (mortality >= 98) return 'Susceptible';
  if (mortality >= 90) return 'Possible resistance';
  return 'Resistant';
}
