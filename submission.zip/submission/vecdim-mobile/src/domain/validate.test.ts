import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { haversineKm, mortalityPct, whoClass } from './reference';
import { assessDeviceRecord, assessGpsAccuracy, type DeviceRecord } from './validate';

function record(overrides: Partial<DeviceRecord> = {}): DeviceRecord {
  return {
    recordId: 'a',
    state: 'Osun',
    lga: 'Osogbo',
    ward: 'Osogbo Ward 2',
    latitude: 7.77,
    longitude: 4.56,
    gpsAccuracyM: 6,
    collectionDate: '2026-10-07',
    species: 'An. gambiae s.s.',
    insecticide: 'Permethrin',
    nExposed: 100,
    nDead: 54,
    larvalDensity: 6,
    urban: 1,
    irsCovered: 0,
    itnUsePct: 61.5,
    ...overrides,
  };
}

describe('device rules', () => {
  it('accepts a complete Osogbo sample', () => {
    const issues = assessDeviceRecord(record(), [], '2026-10-26');
    assert.equal(issues.length, 0);
  });

  it('blocks n_dead above n_exposed', () => {
    const issues = assessDeviceRecord(record({ nDead: 120 }), [], '2026-10-26');
    assert.equal(issues[0]?.rule, 'n_dead_gt_n_exposed');
    assert.match(issues[0]?.message ?? '', /n_dead \(120\) is more than n_exposed \(100\)/);
  });

  it('warns when Ife Central is paired with the Osogbo point', () => {
    const issues = assessDeviceRecord(
      record({ lga: 'Ife Central', ward: 'Ife Central Ward 1' }),
      [],
      '2026-10-26',
    );
    const far = issues.find((issue) => issue.rule === 'GPS_far_from_lga');
    assert.equal(far?.severity, 'warn');
    assert.match(far?.message ?? '', /32\.2 km/);
    assert.ok(Math.abs(haversineKm(7.77, 4.56, 7.48, 4.56) - 32.2) < 0.05);
  });

  it('warns the later duplicate and keeps the earlier record id', () => {
    const earlier = record({ recordId: 'a' });
    const later = record({ recordId: 'b' });
    assert.equal(
      assessDeviceRecord(earlier, [later], '2026-10-26').some((issue) => issue.rule === 'duplicate'),
      false,
    );
    assert.equal(
      assessDeviceRecord(later, [earlier], '2026-10-26').some((issue) => issue.rule === 'duplicate'),
      true,
    );
  });

  it('blocks a collection date after the device clock', () => {
    const issues = assessDeviceRecord(record({ collectionDate: '2099-01-01' }), [], '2026-10-26');
    assert.equal(issues.find((issue) => issue.rule === 'future_date')?.severity, 'block');
  });

  it('classifies GPS accuracy at the 10 m and 50 m edges', () => {
    const cases: Array<[number | null, string | null]> = [
      [10, null],
      [10.1, 'GPS_accuracy_poor'],
      [50, 'GPS_accuracy_poor'],
      [50.1, 'GPS_accuracy_unusable'],
      [null, 'GPS_accuracy_unusable'],
    ];
    for (const [accuracy, rule] of cases) {
      assert.equal(assessGpsAccuracy(accuracy)?.rule ?? null, rule);
    }
  });
});

describe('WHO class', () => {
  it('uses mortality rounded to 1 decimal', () => {
    assert.equal(whoClass(mortalityPct(899, 1000)), 'Resistant');
    assert.equal(whoClass(90), 'Possible resistance');
    assert.equal(whoClass(97.9), 'Possible resistance');
    assert.equal(whoClass(98), 'Susceptible');
  });
});
