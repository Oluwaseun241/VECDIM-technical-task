import {
  NIGERIA,
  STATE_BOXES,
  haversineKm,
  lookupLga,
  mortalityPct,
  wardsFor,
  whoClass,
} from './reference';

export interface DeviceRecord {
  recordId: string;
  state: string | null;
  lga: string | null;
  ward: string | null;
  latitude: number | null;
  longitude: number | null;
  gpsAccuracyM: number | null;
  collectionDate: string;
  species: string | null;
  insecticide: string | null;
  nExposed: number | null;
  nDead: number | null;
  larvalDensity: number | null;
  urban: 0 | 1 | null;
  irsCovered: 0 | 1 | null;
  itnUsePct: number | null;
}

export interface DeviceIssue {
  rule: string;
  field: string;
  severity: 'block' | 'warn';
  message: string;
}

export function assessDeviceRecord(
  record: DeviceRecord,
  saved: readonly DeviceRecord[],
  today: string,
): DeviceIssue[] {
  const issues: DeviceIssue[] = [];
  const block = (rule: string, field: string, message: string) =>
    issues.push({ rule, field, severity: 'block', message });
  const warn = (rule: string, field: string, message: string) =>
    issues.push({ rule, field, severity: 'warn', message });

  if (!record.state) block('GPS_state_mismatch', 'state', 'Choose a pilot state: Lagos, Kano, or Osun.');
  if (!record.lga) block('missing_core', 'lga', 'Choose the LGA where you collected this sample.');
  if (!record.ward) block('missing_core', 'ward', 'Choose the ward where you collected this sample.');
  if (
    record.lga &&
    record.ward &&
    !wardsFor(record.lga).includes(record.ward)
  ) {
    block('missing_core', 'ward', `Ward must be ${record.lga} Ward 1 through ${record.lga} Ward 6.`);
  }
  if (record.lga && record.state && !lookupLga(record.state, record.lga)) {
    block('missing_core', 'lga', `${record.lga} is not a pilot LGA for ${record.state}. Choose a pilot LGA.`);
  }
  if (!record.collectionDate) block('missing_core', 'collection_date', 'Choose the collection date.');
  if (!record.species) block('missing_core', 'species', 'Species is missing. Choose the mosquito species.');
  if (!record.insecticide) block('missing_core', 'insecticide', 'Choose the insecticide.');
  if (record.nExposed === null) block('missing_core', 'n_exposed', 'Enter a number for n_exposed.');
  else if (!Number.isInteger(record.nExposed) || record.nExposed < 1 || record.nExposed > 500) {
    block('missing_core', 'n_exposed', 'n_exposed must be a whole number from 1 to 500.');
  }
  if (record.nDead === null) block('missing_core', 'n_dead', 'Enter a number for n_dead.');
  else if (!Number.isInteger(record.nDead) || record.nDead < 0) {
    block('n_dead_gt_n_exposed', 'n_dead', 'n_dead must be a whole number from 0 up to n_exposed.');
  }
  if (
    record.nDead !== null &&
    record.nExposed !== null &&
    record.nDead > record.nExposed
  ) {
    block(
      'n_dead_gt_n_exposed',
      'n_dead',
      `n_dead (${record.nDead}) is more than n_exposed (${record.nExposed}). Correct the number of dead mosquitoes.`,
    );
  }
  if (record.larvalDensity === null) {
    block('missing_core', 'larval_density', 'Enter the larval density (larvae per dip).');
  } else if (!Number.isInteger(record.larvalDensity) || record.larvalDensity < 0) {
    block('missing_core', 'larval_density', 'Larval density must be a whole number, 0 or more.');
  }
  if (record.urban === null) block('missing_core', 'urban', 'Set urban to yes or no.');
  if (record.irsCovered === null) {
    block(
      'missing_core',
      'irs_covered',
      'Set whether this place had indoor residual spraying in the last 12 months.',
    );
  }
  if (record.itnUsePct === null) {
    block('missing_core', 'itn_use_pct', 'ITN use percent is missing. Enter a value from 0 to 100.');
  } else if (record.itnUsePct < 0 || record.itnUsePct > 100) {
    block('missing_core', 'itn_use_pct', 'ITN use percent must be from 0 to 100.');
  }

  if (record.latitude === null || record.longitude === null) {
    block('missing_core', 'latitude', 'Capture the GPS location.');
  } else {
    const { latitude: lat, longitude: lon } = record;
    const insideNigeria =
      lat >= NIGERIA.latMin &&
      lat <= NIGERIA.latMax &&
      lon >= NIGERIA.lonMin &&
      lon <= NIGERIA.lonMax;
    if (!insideNigeria) {
      block(
        'GPS_outside_nigeria',
        lat < NIGERIA.latMin || lat > NIGERIA.latMax ? 'latitude' : 'longitude',
        'This point is outside Nigeria (latitude 4 to 14, longitude 2.5 to 15). Recapture the GPS location.',
      );
    }
    if (lat === 0 && lon === 0) {
      block(
        'GPS_zero_zero',
        'latitude',
        'Latitude and longitude are 0, 0, which is not a collection site. Recapture the GPS location.',
      );
    }
    const box = record.state ? STATE_BOXES[record.state as keyof typeof STATE_BOXES] : undefined;
    if (record.state && box) {
      const inside =
        lat >= box.latMin && lat <= box.latMax && lon >= box.lonMin && lon <= box.lonMax;
      if (!inside) {
        block(
          'GPS_state_mismatch',
          'latitude',
          `This location is outside ${record.state} (latitude ${box.latMin} to ${box.latMax}, longitude ${box.lonMin} to ${box.lonMax}). Recapture the GPS location or choose the correct state.`,
        );
      }
    }
    const lga = lookupLga(record.state, record.lga);
    if (record.lga && !lga) {
      warn(
        'GPS_far_from_lga',
        'lga',
        `${record.lga} is not a known pilot LGA. Choose the LGA where you collected this sample, or recapture the location.`,
      );
    } else if (lga) {
      const km = haversineKm(lat, lon, lga.refLat, lga.refLon);
      if (km > 25) {
        const shown = (Math.round(km * 10) / 10).toFixed(1);
        warn(
          'GPS_far_from_lga',
          'lga',
          `Your location is ${shown} km from ${record.lga}. Check the LGA, or recapture the location.`,
        );
      }
    }
  }

  if (record.collectionDate && record.collectionDate > today) {
    block(
      'future_date',
      'collection_date',
      `Collection date ${record.collectionDate} is in the future. Choose today or an earlier date.`,
    );
  }

  const accuracy = assessGpsAccuracy(record.gpsAccuracyM);
  if (accuracy) issues.push(accuracy);

  if (isDuplicate(record, saved)) {
    warn(
      'duplicate',
      'ward',
      'Another record has the same ward, date, species, insecticide, and mosquito counts, and its record ID comes first. Check that this sample was not entered twice. You can still save it.',
    );
  }

  return issues;
}

export function assessGpsAccuracy(accuracyM: number | null): DeviceIssue | null {
  if (accuracyM === null || !Number.isFinite(accuracyM) || accuracyM > 50) {
    const reading = accuracyM === null || !Number.isFinite(accuracyM) ? null : String(accuracyM);
    return {
      rule: 'GPS_accuracy_unusable',
      field: 'gps_accuracy_m',
      severity: 'block',
      message:
        reading === null
          ? 'The phone did not report GPS accuracy. Move to open sky and recapture the location.'
          : `GPS accuracy is ${reading} m, which is too poor to save (worse than 50 m). Move to open sky and recapture the location.`,
    };
  }
  if (accuracyM > 10) {
    return {
      rule: 'GPS_accuracy_poor',
      field: 'gps_accuracy_m',
      severity: 'warn',
      message: `GPS accuracy is ${accuracyM} m. Target is 10 m or better. You can save this record, or move to open sky and recapture.`,
    };
  }
  return null;
}

function isDuplicate(record: DeviceRecord, saved: readonly DeviceRecord[]): boolean {
  const group = [record, ...saved.filter((row) => row.recordId !== record.recordId)];
  const ordered = [...group].sort((a, b) =>
    a.recordId < b.recordId ? -1 : a.recordId > b.recordId ? 1 : 0,
  );
  const seen = new Set<string>();
  for (const row of ordered) {
    const key = duplicateKey(row);
    if (seen.has(key)) {
      if (row.recordId === record.recordId) return true;
    } else {
      seen.add(key);
    }
  }
  return false;
}

function duplicateKey(record: DeviceRecord): string {
  return [
    record.ward,
    record.collectionDate,
    record.species,
    record.insecticide,
    record.nExposed,
    record.nDead,
  ]
    .map((part) => (part === null || part === '' ? 'NA' : String(part)))
    .join(' ');
}

export function liveMortality(dead: number | null, exposed: number | null): {
  percent: number | null;
  who: string | null;
} {
  const percent = mortalityPct(dead, exposed);
  return { percent, who: whoClass(percent) };
}
