import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import NetInfo from '@react-native-community/netinfo';
import * as Crypto from 'expo-crypto';
import { AppState } from 'react-native';
import { assessDeviceRecord, type DeviceRecord } from '../domain/validate';
import { todayString } from '../domain/reference';
import { syncBatch } from './api';
import {
  FIELD_USERS,
  loadStore,
  saveStore,
  type RecordStatus,
  type StoredRecord,
} from './persistence';
import { nextSyncDelayMs } from './sync-backoff';

interface StoreFile {
  userId: string | null;
  records: StoredRecord[];
}

export interface SaveOutcome {
  blocked: boolean;
  needsConfirm: boolean;
  record: StoredRecord;
}

interface RecordsApi {
  ready: boolean;
  userId: string | null;
  userState: string | null;
  records: StoredRecord[];
  draft: StoredRecord | null;
  syncError: string | null;
  signIn: (userId: string) => Promise<void>;
  signOut: () => Promise<void>;
  startDraft: () => Promise<StoredRecord>;
  writeRecord: (record: StoredRecord) => Promise<void>;
  saveRecord: (
    record: StoredRecord,
    options?: { acceptWarnings?: boolean },
  ) => Promise<SaveOutcome>;
  discard: (recordId: string) => Promise<void>;
  syncNow: () => Promise<void>;
}

const RecordsContext = createContext<RecordsApi | null>(null);

export function RecordsProvider({ children }: { children: ReactNode }) {
  const [file, setFile] = useState<StoreFile | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);
  const fileRef = useRef<StoreFile | null>(null);
  const syncingRef = useRef(false);
  const syncAttemptRef = useRef(0);
  const syncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scheduleRetry = useCallback((run: () => void) => {
    if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    const delay = nextSyncDelayMs(syncAttemptRef.current);
    syncAttemptRef.current += 1;
    syncTimerRef.current = setTimeout(run, delay);
  }, []);

  useEffect(() => {
    void loadStore().then((loaded) => {
      fileRef.current = loaded;
      setFile(loaded);
    });
  }, []);

  const persist = useCallback(async (next: StoreFile) => {
    fileRef.current = next;
    setFile(next);
    await saveStore(next);
  }, []);

  const user = FIELD_USERS.find((row) => row.userId === file?.userId) ?? null;
  const records = useMemo(
    () => (file?.records ?? []).filter((row) => row.userId === file?.userId),
    [file],
  );
  const draft = records.find((row) => row.status === 'draft') ?? null;

  const signIn = useCallback(
    async (userId: string) => {
      if (!file) return;
      await persist({ ...file, userId });
    },
    [file, persist],
  );

  const signOut = useCallback(async () => {
    if (!file) return;
    await persist({ ...file, userId: null });
  }, [file, persist]);

  const writeRecord = useCallback(
    async (record: StoredRecord) => {
      if (!file) return;
      const next = upsert(file, { ...record, updatedAt: new Date().toISOString() });
      await persist(next);
    },
    [file, persist],
  );

  const startDraft = useCallback(async () => {
    if (!file || !user) throw new Error('Sign in before starting a record.');
    if (draft) return draft;
    const created: StoredRecord = {
      recordId: Crypto.randomUUID(),
      userId: user.userId,
      status: 'draft',
      updatedAt: new Date().toISOString(),
      capturedAt: null,
      state: user.state,
      lga: null,
      ward: null,
      latitude: null,
      longitude: null,
      gpsAccuracyM: null,
      collectionDate: todayString(),
      species: null,
      insecticide: null,
      nExposed: '',
      nDead: '',
      larvalDensity: '',
      urban: null,
      irsCovered: null,
      itnUsePct: '',
      messages: [],
    };
    await persist(upsert(file, created));
    return created;
  }, [draft, file, persist, user]);

  const discard = useCallback(
    async (recordId: string) => {
      if (!file) return;
      await persist({ ...file, records: file.records.filter((row) => row.recordId !== recordId) });
    },
    [file, persist],
  );

  const flushPending = useCallback(async () => {
    const current = fileRef.current;
    const signedIn = FIELD_USERS.find((row) => row.userId === current?.userId) ?? null;
    if (!current || !signedIn || syncingRef.current) return;
    const pending = current.records.filter(
      (row) => row.userId === signedIn.userId && row.status === 'pending_sync',
    );
    if (pending.length === 0) {
      syncAttemptRef.current = 0;
      if (syncTimerRef.current) {
        clearTimeout(syncTimerRef.current);
        syncTimerRef.current = null;
      }
      return;
    }
    syncingRef.current = true;
    try {
      const results = await syncBatch(signedIn.userId, pending);
      const byId = new Map(results.map((row) => [row.record_id, row]));
      const latest = fileRef.current ?? current;
      await persist({
        ...latest,
        records: latest.records.map((row) => {
          const result = byId.get(row.recordId);
          return result ? applyResult(row, result) : row;
        }),
      });
      setSyncError(null);
      syncAttemptRef.current = 0;
      if (syncTimerRef.current) {
        clearTimeout(syncTimerRef.current);
        syncTimerRef.current = null;
      }
    } catch (error) {
      setSyncError(
        error instanceof Error
          ? error.message
          : 'Saved on this phone. Sync will retry when you are online.',
      );
      scheduleRetry(() => {
        void flushPending();
      });
    } finally {
      syncingRef.current = false;
    }
  }, [persist, scheduleRetry]);

  const syncNow = useCallback(async () => {
    syncAttemptRef.current = 0;
    if (syncTimerRef.current) {
      clearTimeout(syncTimerRef.current);
      syncTimerRef.current = null;
    }
    await flushPending();
  }, [flushPending]);

  useEffect(() => {
    const unsubNet = NetInfo.addEventListener((state) => {
      if (state.isConnected && state.isInternetReachable !== false) {
        syncAttemptRef.current = 0;
        void flushPending();
      }
    });
    const unsubApp = AppState.addEventListener('change', (state) => {
      if (state === 'active') void flushPending();
    });
    return () => {
      unsubNet();
      unsubApp.remove();
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    };
  }, [flushPending]);

  const saveRecord = useCallback(
    async (record: StoredRecord, options?: { acceptWarnings?: boolean }) => {
      const current = fileRef.current;
      const signedIn = FIELD_USERS.find((row) => row.userId === current?.userId) ?? null;
      if (!current || !signedIn) {
        return { blocked: true, needsConfirm: false, record };
      }
      const others = current.records
        .filter(
          (row) =>
            row.userId === signedIn.userId &&
            row.recordId !== record.recordId &&
            row.status !== 'draft',
        )
        .map(toDevice);
      const issues = assessDeviceRecord(toDevice(record), others, todayString());
      const blocked = issues.some((issue) => issue.severity === 'block');
      const warns = issues.filter((issue) => issue.severity === 'warn');
      const needsConfirm = !blocked && warns.length > 0 && !options?.acceptWarnings;

      if (blocked || needsConfirm) {
        const held: StoredRecord = {
          ...record,
          updatedAt: new Date().toISOString(),
          messages: issues,
          status: record.status === 'rejected' ? 'rejected' : 'draft',
        };
        await persist(upsert(current, held));
        return { blocked, needsConfirm, record: held };
      }

      const nextRecord: StoredRecord = {
        ...record,
        updatedAt: new Date().toISOString(),
        messages: issues,
        status: 'pending_sync',
        capturedAt: record.capturedAt ?? new Date().toISOString(),
      };
      await persist(upsert(current, nextRecord));
      await flushPending();
      const after = fileRef.current?.records.find((row) => row.recordId === nextRecord.recordId);
      return { blocked: false, needsConfirm: false, record: after ?? nextRecord };
    },
    [flushPending, persist],
  );

  const value: RecordsApi = {
    ready: file !== null,
    userId: user?.userId ?? null,
    userState: user?.state ?? null,
    records,
    draft,
    syncError,
    signIn,
    signOut,
    startDraft,
    writeRecord,
    saveRecord,
    discard,
    syncNow,
  };

  return <RecordsContext.Provider value={value}>{children}</RecordsContext.Provider>;
}

export function useRecords(): RecordsApi {
  const value = useContext(RecordsContext);
  if (!value) throw new Error('useRecords must be used inside RecordsProvider.');
  return value;
}

function upsert(file: StoreFile, record: StoredRecord): StoreFile {
  const exists = file.records.some((row) => row.recordId === record.recordId);
  const records = exists
    ? file.records.map((row) => (row.recordId === record.recordId ? record : row))
    : [...file.records, record];
  return { ...file, records };
}

function applyResult(
  record: StoredRecord,
  result: {
    status: string;
    flags: { rule: string; field: string; message: string }[];
    errors: { rule: string; field: string; message: string }[];
  },
): StoredRecord {
  if (result.status === 'rejected') {
    return {
      ...record,
      status: 'rejected',
      messages: result.errors.map((issue) => ({ ...issue, severity: 'block' as const })),
      updatedAt: new Date().toISOString(),
    };
  }
  const status: RecordStatus =
    result.status === 'accepted_with_flags' ? 'synced_with_flags' : 'synced';
  return {
    ...record,
    status,
    messages: result.flags.map((issue) => ({ ...issue, severity: 'warn' as const })),
    updatedAt: new Date().toISOString(),
  };
}

export function toDevice(record: StoredRecord): DeviceRecord {
  return {
    recordId: record.recordId,
    state: record.state,
    lga: record.lga,
    ward: record.ward,
    latitude: record.latitude,
    longitude: record.longitude,
    gpsAccuracyM: record.gpsAccuracyM,
    collectionDate: record.collectionDate,
    species: record.species,
    insecticide: record.insecticide,
    nExposed: parseNumber(record.nExposed),
    nDead: parseNumber(record.nDead),
    larvalDensity: parseNumber(record.larvalDensity),
    urban: record.urban,
    irsCovered: record.irsCovered,
    itnUsePct: parseNumber(record.itnUsePct),
  };
}

function parseNumber(value: string): number | null {
  if (value.trim() === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}
