import AsyncStorage from '@react-native-async-storage/async-storage';
import type { DeviceIssue } from '../domain/validate';

export const FIELD_USERS = [
  { userId: 'u_field_01', name: 'Field worker, Lagos', state: 'Lagos' },
  { userId: 'u_field_02', name: 'Field worker, Kano', state: 'Kano' },
  { userId: 'u_field_03', name: 'Field worker, Osun', state: 'Osun' },
] as const;

export type RecordStatus = 'draft' | 'pending_sync' | 'synced' | 'synced_with_flags' | 'rejected';

export interface StoredRecord {
  recordId: string;
  userId: string;
  status: RecordStatus;
  updatedAt: string;
  capturedAt: string | null;
  state: string | null;
  lga: string | null;
  ward: string | null;
  latitude: number | null;
  longitude: number | null;
  gpsAccuracyM: number | null;
  collectionDate: string;
  species: string | null;
  insecticide: string | null;
  nExposed: string;
  nDead: string;
  larvalDensity: string;
  urban: 0 | 1 | null;
  irsCovered: 0 | 1 | null;
  itnUsePct: string;
  messages: DeviceIssue[];
}

interface StoreFile {
  userId: string | null;
  records: StoredRecord[];
}

const KEY = 'vecdim.field.v1';

const empty: StoreFile = { userId: null, records: [] };

export async function loadStore(): Promise<StoreFile> {
  const raw = await AsyncStorage.getItem(KEY);
  if (!raw) return empty;
  const parsed = JSON.parse(raw) as StoreFile;
  return {
    userId: parsed.userId ?? null,
    records: Array.isArray(parsed.records) ? parsed.records : [],
  };
}

export async function saveStore(file: StoreFile): Promise<void> {
  await AsyncStorage.setItem(KEY, JSON.stringify(file));
}
