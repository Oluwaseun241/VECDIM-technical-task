/** Exponential back-off for offline sync retries. Caps at 60 seconds. */
export function nextSyncDelayMs(attempt: number): number {
  const safe = Math.max(0, Math.floor(attempt));
  return Math.min(60_000, 1000 * 2 ** safe);
}
