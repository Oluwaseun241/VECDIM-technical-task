import Constants from 'expo-constants';
import { Platform } from 'react-native';
import type { StoredRecord } from './persistence';

function packHost(): string | null {
  const candidates = [
    Constants.expoGoConfig?.debuggerHost,
    Constants.expoConfig?.hostUri,
    (
      Constants as {
        manifest?: { debuggerHost?: string };
      }
    ).manifest?.debuggerHost,
  ];
  for (const value of candidates) {
    if (typeof value === 'string' && value.length > 0) {
      return value.split(':')[0] ?? null;
    }
  }
  return null;
}

function resolveApiUrl(): string {
  if (process.env.EXPO_PUBLIC_API_URL) return process.env.EXPO_PUBLIC_API_URL;
  const host = packHost();
  if (host) return `http://${host}:3000/api/v1`;
  // Android emulator reaches the host machine on this address.
  if (Platform.OS === 'android') return 'http://10.0.2.2:3000/api/v1';
  return 'http://127.0.0.1:3000/api/v1';
}

const API_URL = resolveApiUrl();

export interface SyncResult {
  record_id: string;
  status: 'accepted' | 'accepted_with_flags' | 'rejected' | 'already_received';
  flags: { rule: string; field: string; message: string }[];
  errors: { rule: string; field: string; message: string }[];
}

export async function syncBatch(userId: string, records: StoredRecord[]): Promise<SyncResult[]> {
  let response: Response;
  try {
    response = await fetch(`${API_URL}/records/batch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-User-Id': userId,
      },
      body: JSON.stringify({ records: records.map(toPayload) }),
    });
  } catch {
    throw new Error(
      `Could not reach the API at ${API_URL}. Keep the phone on the same Wi‑Fi as this computer, and run the API with npm run start:dev in vecdim-backend.`,
    );
  }
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Sync failed (${response.status}).`);
  }
  const body = (await response.json()) as { results: SyncResult[] };
  return body.results;
}

function toPayload(record: StoredRecord) {
  return {
    record_id: record.recordId,
    state: record.state,
    lga: record.lga,
    ward: record.ward,
    latitude: record.latitude,
    longitude: record.longitude,
    gps_accuracy_m: record.gpsAccuracyM,
    collection_date: record.collectionDate,
    species: record.species,
    insecticide: record.insecticide,
    n_exposed: numberOrNull(record.nExposed),
    n_dead: numberOrNull(record.nDead),
    larval_density: numberOrNull(record.larvalDensity),
    urban: record.urban,
    irs_covered: record.irsCovered,
    itn_use_pct: numberOrNull(record.itnUsePct),
    captured_at: record.capturedAt,
  };
}

function numberOrNull(value: string): number | null {
  if (value.trim() === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}
