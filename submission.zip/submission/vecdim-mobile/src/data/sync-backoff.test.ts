import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { nextSyncDelayMs } from './sync-backoff';

describe('nextSyncDelayMs', () => {
  it('doubles until the 60 second cap', () => {
    assert.equal(nextSyncDelayMs(0), 1000);
    assert.equal(nextSyncDelayMs(1), 2000);
    assert.equal(nextSyncDelayMs(2), 4000);
    assert.equal(nextSyncDelayMs(3), 8000);
    assert.equal(nextSyncDelayMs(5), 32000);
    assert.equal(nextSyncDelayMs(6), 60000);
    assert.equal(nextSyncDelayMs(10), 60000);
  });
});
