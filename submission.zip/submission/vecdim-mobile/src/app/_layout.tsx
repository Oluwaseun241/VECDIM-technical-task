import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import { RecordsProvider, useRecords } from '@/data/records';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  return (
    <RecordsProvider>
      <SplashGate />
    </RecordsProvider>
  );
}

function SplashGate() {
  const { ready } = useRecords();
  useEffect(() => {
    if (ready) void SplashScreen.hideAsync();
  }, [ready]);

  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: '#143D2E' },
        headerTintColor: '#F4F7F5',
        headerTitleStyle: { fontWeight: '600' },
        contentStyle: { backgroundColor: '#F4F7F5' },
      }}>
      <Stack.Screen name="index" options={{ title: 'VECDIM field' }} />
      <Stack.Screen name="record/[id]" options={{ title: 'Sample' }} />
    </Stack>
  );
}
