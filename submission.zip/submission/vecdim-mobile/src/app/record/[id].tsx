import DateTimePicker, { type DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Location from 'expo-location';
import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  AppState,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import {
  INSECTICIDES,
  SPECIES,
  STATES,
  lgasFor,
  todayString,
  wardsFor,
} from '@/domain/reference';
import { liveMortality } from '@/domain/validate';
import type { StoredRecord } from '@/data/persistence';
import { toDevice, useRecords } from '@/data/records';

export default function RecordScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { ready, records, writeRecord, saveRecord, discard } = useRecords();
  const stored = records.find((row) => row.recordId === id);
  const [form, setForm] = useState<StoredRecord | null>(null);
  const [gpsNote, setGpsNote] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [awaitingWarnConfirm, setAwaitingWarnConfirm] = useState(false);
  const watch = useRef<Location.LocationSubscription | null>(null);
  const gpsStarted = useRef(false);
  const formRef = useRef<StoredRecord | null>(null);

  useEffect(() => {
    if (stored && !form) setForm(stored);
  }, [stored, form]);

  useEffect(() => {
    formRef.current = form;
  }, [form]);

  const locked = form?.status === 'synced' || form?.status === 'synced_with_flags';

  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!form || locked) return;
    timer.current = setTimeout(() => {
      void writeRecord(form);
    }, 1500);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [form, locked, writeRecord]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if ((state === 'background' || state === 'inactive') && form && !locked) {
        void writeRecord(form);
      }
    });
    return () => sub.remove();
  }, [form, locked, writeRecord]);

  useEffect(() => () => watch.current?.remove(), []);

  function patch(partial: Partial<StoredRecord>) {
    setAwaitingWarnConfirm(false);
    setForm((current) => (current ? { ...current, ...partial, messages: [] } : current));
  }

  async function captureGps() {
    setGpsNote(null);
    const permission = await Location.requestForegroundPermissionsAsync();
    if (permission.status !== 'granted') {
      setGpsNote('Location permission is needed to record where this sample was collected.');
      return;
    }
    watch.current?.remove();
    const started = Date.now();
    setGpsNote('Waiting for a better GPS signal. Move to open sky.');
    watch.current = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 0 },
      (fix) => {
        const accuracy = fix.coords.accuracy;
        patch({
          latitude: fix.coords.latitude,
          longitude: fix.coords.longitude,
          gpsAccuracyM: accuracy === null || accuracy === undefined ? null : accuracy,
        });
        if (accuracy !== null && accuracy !== undefined && accuracy <= 10) {
          watch.current?.remove();
          setGpsNote(`Accuracy: ${Math.round(accuracy)} m`);
          return;
        }
        if (Date.now() - started >= 60_000) {
          watch.current?.remove();
          setGpsNote(
            accuracy === null || accuracy === undefined
              ? 'The phone did not report GPS accuracy. Move to open sky and recapture the location.'
              : `Accuracy: ${Math.round(accuracy)} m. You can save this if it is 50 m or better, or recapture.`,
          );
        }
      },
    );
  }

  useEffect(() => {
    if (!form || locked || gpsStarted.current) return;
    if (form.latitude !== null && form.longitude !== null) return;
    gpsStarted.current = true;
    void captureGps();
  }, [form, locked]);

  if (!form) {
    if (!ready || stored) return null;
    return (
      <View style={styles.missing}>
        <Text>This record is not on this phone.</Text>
      </View>
    );
  }

  const current = form;

  function messages(field: string): string[] {
    return form?.messages.filter((issue) => issue.field === field).map((issue) => issue.message) ?? [];
  }

  async function commitSave(acceptWarnings: boolean) {
    if (timer.current) clearTimeout(timer.current);
    setSaving(true);
    try {
      const result = await saveRecord(formRef.current ?? current, { acceptWarnings });
      setForm(result.record);
      if (result.blocked) {
        setAwaitingWarnConfirm(false);
        return;
      }
      if (result.needsConfirm) {
        setAwaitingWarnConfirm(true);
        return;
      }
      setAwaitingWarnConfirm(false);
      router.back();
    } finally {
      setSaving(false);
    }
  }

  async function onSave() {
    await commitSave(false);
  }

  async function onSaveAnyway() {
    await commitSave(true);
  }

  function onDiscard() {
    const run = () => {
      void discard(current.recordId).then(() => router.back());
    };
    if (Platform.OS === 'web') {
      if (globalThis.confirm('Discard this unfinished record?')) run();
      return;
    }
    Alert.alert('Discard this unfinished record?', 'The draft will be removed from this phone.', [
      { text: 'Keep', style: 'cancel' },
      { text: 'Discard', style: 'destructive', onPress: run },
    ]);
  }

  const mortality = liveMortality(toDevice(form).nDead, toDevice(form).nExposed);
  const lgas = lgasFor(form.state);
  const wards = wardsFor(form.lga);

  return (
    <ScrollView contentContainerStyle={styles.page}>
      {form.messages.length > 0 ? (
        <View style={awaitingWarnConfirm ? styles.warnSummary : styles.summary}>
          {awaitingWarnConfirm ? (
            <Text style={styles.warnTitle}>Check these warnings before this sample is saved.</Text>
          ) : null}
          {form.messages.map((issue) => (
            <Text key={`${issue.rule}-${issue.field}`} style={issue.severity === 'warn' ? styles.warn : styles.error}>
              {issue.message}
            </Text>
          ))}
        </View>
      ) : null}

      <Text style={styles.label}>State</Text>
      <Choices
        options={STATES.map((state) => state)}
        selected={form.state}
        disabled={locked}
        onSelect={(state) => patch({ state, lga: null, ward: null })}
      />
      <Hints lines={messages('state')} />

      <Text style={styles.label}>LGA</Text>
      <Choices
        options={lgas.map((row) => row.lga)}
        selected={form.lga}
        disabled={locked || !form.state}
        onSelect={(lga) => patch({ lga, ward: null })}
      />
      <Hints lines={messages('lga')} />

      <Text style={styles.label}>Ward</Text>
      <Choices
        options={wards}
        selected={form.ward}
        disabled={locked || !form.lga}
        onSelect={(ward) => patch({ ward })}
      />
      <Hints lines={messages('ward')} />

      <Text style={styles.label}>Location</Text>
      <Text style={styles.value}>
        {form.latitude === null || form.longitude === null
          ? 'No GPS fix yet'
          : `${form.latitude.toFixed(5)}, ${form.longitude.toFixed(5)}`}
      </Text>
      <Text style={styles.value}>
        {form.gpsAccuracyM === null ? 'Accuracy: not reported' : `Accuracy: ${Math.round(form.gpsAccuracyM)} m`}
      </Text>
      {gpsNote ? <Text style={styles.note}>{gpsNote}</Text> : null}
      {locked ? null : (
        <Pressable accessibilityRole="button" style={styles.secondary} onPress={() => void captureGps()}>
          <Text style={styles.secondaryText}>Recapture GPS</Text>
        </Pressable>
      )}
      <Hints lines={messages('latitude').concat(messages('longitude'), messages('gps_accuracy_m'))} />

      <Text style={styles.label}>Collection date</Text>
      <DateField
        value={form.collectionDate}
        disabled={locked}
        onChange={(collectionDate) => patch({ collectionDate })}
      />
      <Hints lines={messages('collection_date')} />

      <Text style={styles.label}>Species</Text>
      <Choices
        options={[...SPECIES]}
        selected={form.species}
        disabled={locked}
        onSelect={(species) => patch({ species })}
      />
      <Hints lines={messages('species')} />

      <Text style={styles.label}>Insecticide</Text>
      <Choices
        options={[...INSECTICIDES]}
        selected={form.insecticide}
        disabled={locked}
        onSelect={(insecticide) => patch({ insecticide })}
      />
      <Hints lines={messages('insecticide')} />

      <Text style={styles.label}>Mosquitoes exposed</Text>
      <FieldInput
        value={form.nExposed}
        disabled={locked}
        keyboard="number-pad"
        onChange={(nExposed) => patch({ nExposed })}
      />
      <Hints lines={messages('n_exposed')} />

      <Text style={styles.label}>Mosquitoes dead</Text>
      <FieldInput
        value={form.nDead}
        disabled={locked}
        keyboard="number-pad"
        onChange={(nDead) => patch({ nDead })}
      />
      <Hints lines={messages('n_dead')} />

      <Text style={styles.mortality}>
        {mortality.percent === null
          ? 'Mortality appears when both counts are entered.'
          : `Mortality ${mortality.percent.toFixed(1)}% · ${mortality.who}`}
      </Text>

      <Text style={styles.label}>Larval density (larvae per dip)</Text>
      <FieldInput
        value={form.larvalDensity}
        disabled={locked}
        keyboard="number-pad"
        onChange={(larvalDensity) => patch({ larvalDensity })}
      />
      <Hints lines={messages('larval_density')} />

      <Text style={styles.label}>Urban</Text>
      <Choices
        options={['Yes', 'No']}
        selected={form.urban === null ? null : form.urban === 1 ? 'Yes' : 'No'}
        disabled={locked}
        onSelect={(value) => patch({ urban: value === 'Yes' ? 1 : 0 })}
      />
      <Hints lines={messages('urban')} />

      <Text style={styles.label}>Indoor residual spraying in the last 12 months</Text>
      <Choices
        options={['Yes', 'No']}
        selected={form.irsCovered === null ? null : form.irsCovered === 1 ? 'Yes' : 'No'}
        disabled={locked}
        onSelect={(value) => patch({ irsCovered: value === 'Yes' ? 1 : 0 })}
      />
      <Hints lines={messages('irs_covered')} />

      <Text style={styles.label}>Bed-net use (percent of households)</Text>
      <FieldInput
        value={form.itnUsePct}
        disabled={locked}
        keyboard="decimal-pad"
        onChange={(itnUsePct) => patch({ itnUsePct })}
      />
      <Hints lines={messages('itn_use_pct')} />

      {locked ? null : (
        <View style={styles.actions}>
          {awaitingWarnConfirm ? (
            <>
              <Pressable
                accessibilityRole="button"
                style={styles.primary}
                disabled={saving}
                onPress={() => void onSaveAnyway()}>
                <Text style={styles.primaryText}>{saving ? 'Saving…' : 'Save anyway'}</Text>
              </Pressable>
              <Pressable
                accessibilityRole="button"
                style={styles.secondary}
                disabled={saving}
                onPress={() => setAwaitingWarnConfirm(false)}>
                <Text style={styles.secondaryText}>Keep editing</Text>
              </Pressable>
            </>
          ) : (
            <Pressable accessibilityRole="button" style={styles.primary} disabled={saving} onPress={() => void onSave()}>
              <Text style={styles.primaryText}>
                {saving ? 'Saving…' : form.status === 'rejected' ? 'Resubmit' : 'Save'}
              </Text>
            </Pressable>
          )}
          {form.status === 'draft' ? (
            <Pressable accessibilityRole="button" onPress={onDiscard}>
              <Text style={styles.discard}>Discard draft</Text>
            </Pressable>
          ) : null}
        </View>
      )}
    </ScrollView>
  );
}

function Choices({
  options,
  selected,
  disabled,
  onSelect,
}: {
  options: readonly string[];
  selected: string | null;
  disabled?: boolean;
  onSelect: (value: string) => void;
}) {
  return (
    <View style={styles.choices}>
      {options.map((option) => {
        const on = option === selected;
        return (
          <Pressable
            key={option}
            accessibilityRole="button"
            disabled={disabled}
            onPress={() => onSelect(option)}
            style={[styles.chip, on && styles.chipOn, disabled && styles.chipDisabled]}>
            <Text style={[styles.chipText, on && styles.chipTextOn]}>{option}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function FieldInput({
  value,
  onChange,
  disabled,
  keyboard,
}: {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  keyboard: 'number-pad' | 'decimal-pad';
}) {
  return (
    <TextInput
      value={value}
      editable={!disabled}
      keyboardType={keyboard}
      onChangeText={onChange}
      style={styles.input}
    />
  );
}

function DateField({
  value,
  onChange,
  disabled,
}: {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}) {
  const today = todayString();
  const selected = parseLocalDate(value || today);
  const [androidOpen, setAndroidOpen] = useState(false);

  function commit(next: Date) {
    onChange(todayString(clampToToday(next)));
  }

  if (Platform.OS === 'web') {
    return (
      <input
        type="date"
        value={value || today}
        max={today}
        required
        disabled={disabled}
        onChange={(event) => {
          const next = event.currentTarget.value;
          onChange(next > today ? today : next);
        }}
        style={{ fontSize: 16, padding: 12, borderRadius: 8, border: '1px solid #C5D1CB' }}
      />
    );
  }

  if (disabled) {
    return (
      <View style={styles.input}>
        <Text style={styles.value}>{value || today}</Text>
      </View>
    );
  }

  if (Platform.OS === 'android') {
    return (
      <View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Collection date"
          style={styles.input}
          onPress={() => setAndroidOpen(true)}>
          <Text style={styles.value}>{value || today}</Text>
        </Pressable>
        {androidOpen ? (
          <DateTimePicker
            value={selected}
            mode="date"
            display="default"
            maximumDate={endOfToday()}
            onChange={(event: DateTimePickerEvent, date?: Date) => {
              setAndroidOpen(false);
              if (event.type === 'dismissed' || !date) return;
              commit(date);
            }}
          />
        ) : null}
      </View>
    );
  }

  return (
    <View style={styles.datePickerRow}>
      <DateTimePicker
        value={selected}
        mode="date"
        display="compact"
        maximumDate={endOfToday()}
        onChange={(_event: DateTimePickerEvent, date?: Date) => {
          if (!date) return;
          commit(date);
        }}
      />
    </View>
  );
}

function parseLocalDate(iso: string): Date {
  const [year, month, day] = iso.split('-').map(Number);
  return new Date(year, (month ?? 1) - 1, day ?? 1);
}

function endOfToday(): Date {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
}

function clampToToday(date: Date): Date {
  const today = endOfToday();
  return date.getTime() > today.getTime() ? today : date;
}

function Hints({ lines }: { lines: string[] }) {
  if (lines.length === 0) return null;
  return (
    <View>
      {lines.map((line) => (
        <Text key={line} style={styles.error}>
          {line}
        </Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  page: { padding: 20, gap: 8, paddingBottom: 48 },
  missing: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  label: { marginTop: 12, fontSize: 14, fontWeight: '700', color: '#143D2E' },
  value: { fontSize: 16, color: '#1C2B26' },
  note: { color: '#7A5B12', lineHeight: 20 },
  mortality: { marginTop: 8, fontSize: 16, fontWeight: '600', color: '#143D2E' },
  choices: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { backgroundColor: '#FFFFFF', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: '#C5D1CB' },
  chipOn: { backgroundColor: '#1B6B4A', borderColor: '#1B6B4A' },
  chipDisabled: { opacity: 0.6 },
  chipText: { color: '#143D2E' },
  chipTextOn: { color: '#FFFFFF' },
  input: { backgroundColor: '#FFFFFF', borderRadius: 8, borderWidth: 1, borderColor: '#C5D1CB', padding: 12, fontSize: 16 },
  summary: { backgroundColor: '#FFF6F6', borderRadius: 12, padding: 12, gap: 6 },
  warnSummary: { backgroundColor: '#FFF6E5', borderRadius: 12, padding: 12, gap: 6 },
  warnTitle: { color: '#3F2E10', fontWeight: '700', lineHeight: 20 },
  error: { color: '#8E1B1B', lineHeight: 20 },
  warn: { color: '#7A5B12', lineHeight: 20 },
  actions: { marginTop: 20, gap: 12 },
  primary: { backgroundColor: '#1B6B4A', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  primaryText: { color: '#FFFFFF', fontSize: 17, fontWeight: '600' },
  secondary: { alignSelf: 'flex-start', borderColor: '#1B6B4A', borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  secondaryText: { color: '#1B6B4A', fontWeight: '600' },
  discard: { textAlign: 'center', color: '#8E1B1B', fontSize: 16 },
  datePickerRow: {
    alignSelf: 'flex-start',
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#C5D1CB',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
});
