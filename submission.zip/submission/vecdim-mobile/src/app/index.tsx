import { useRouter } from 'expo-router';
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FIELD_USERS, type RecordStatus, type StoredRecord } from '@/data/persistence';
import { useRecords } from '@/data/records';

const STATUS_LABEL: Record<RecordStatus, string> = {
  draft: 'Draft',
  pending_sync: 'Waiting to sync',
  synced: 'Synced',
  synced_with_flags: 'Synced, with a warning',
  rejected: 'Needs attention',
};

export default function HomeScreen() {
  const router = useRouter();
  const { ready, userId, records, draft, syncError, signIn, signOut, startDraft, discard, syncNow } =
    useRecords();

  if (!ready) return null;

  if (!userId) {
    return (
      <SafeAreaView style={styles.safe}>
        <Text style={styles.lead}>Sign in with a demo field account. Records stay on this phone until they sync.</Text>
        {FIELD_USERS.map((user) => (
          <Pressable
            key={user.userId}
            accessibilityRole="button"
            style={styles.userButton}
            onPress={() => void signIn(user.userId)}>
            <Text style={styles.userName}>{user.name}</Text>
            <Text style={styles.userMeta}>{user.state}</Text>
          </Pressable>
        ))}
      </SafeAreaView>
    );
  }

  const needsAttention = records.filter((row) => row.status === 'rejected');
  const waiting = records.filter((row) => row.status === 'pending_sync');
  const saved = records.filter((row) => row.status === 'synced' || row.status === 'synced_with_flags');

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.row}>
          <Text style={styles.who}>{FIELD_USERS.find((user) => user.userId === userId)?.name}</Text>
          <Pressable accessibilityRole="button" onPress={() => void signOut()}>
            <Text style={styles.link}>Switch</Text>
          </Pressable>
        </View>

        {draft ? (
          <View style={styles.banner}>
            <Text style={styles.bannerTitle}>
              You have an unfinished record from {clock(draft.updatedAt)}. Resume or discard?
            </Text>
            <Pressable accessibilityRole="button" style={styles.primary} onPress={() => open(router, draft.recordId)}>
              <Text style={styles.primaryText}>Resume</Text>
            </Pressable>
            <Pressable accessibilityRole="button" onPress={() => confirmDiscard(draft.recordId, discard)}>
              <Text style={styles.discard}>Discard</Text>
            </Pressable>
          </View>
        ) : (
          <Pressable
            accessibilityRole="button"
            style={styles.primary}
            onPress={() => {
              void startDraft().then((created) => open(router, created.recordId));
            }}>
            <Text style={styles.primaryText}>New sample</Text>
          </Pressable>
        )}

        {syncError ? <Text style={styles.error}>{syncError}</Text> : null}

        {waiting.length > 0 ? (
          <Pressable accessibilityRole="button" style={styles.secondary} onPress={() => void syncNow()}>
            <Text style={styles.secondaryText}>Sync {waiting.length} waiting</Text>
          </Pressable>
        ) : null}

        <Section title="Needs attention" rows={needsAttention} onOpen={(id) => open(router, id)} />
        <Section title="Waiting to sync" rows={waiting} onOpen={(id) => open(router, id)} />
        <Section title="On the server" rows={saved} onOpen={(id) => open(router, id)} />
      </ScrollView>
    </SafeAreaView>
  );
}

function Section({
  title,
  rows,
  onOpen,
}: {
  title: string;
  rows: StoredRecord[];
  onOpen: (id: string) => void;
}) {
  if (rows.length === 0) return null;
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {rows.map((row) => (
        <Pressable
          key={row.recordId}
          accessibilityRole="button"
          style={styles.card}
          onPress={() => onOpen(row.recordId)}>
          <Text style={styles.cardTitle}>
            {row.lga ?? 'No LGA'} · {row.collectionDate}
          </Text>
          <Text style={styles.cardMeta}>{STATUS_LABEL[row.status]}</Text>
          {row.messages[0] ? <Text style={styles.cardMessage}>{row.messages[0].message}</Text> : null}
        </Pressable>
      ))}
    </View>
  );
}

function open(router: ReturnType<typeof useRouter>, id: string) {
  router.push({ pathname: '/record/[id]', params: { id } });
}

function confirmDiscard(recordId: string, discard: (recordId: string) => Promise<void>) {
  const run = () => void discard(recordId);
  if (Platform.OS === 'web') {
    if (globalThis.confirm('Discard this unfinished record?')) run();
    return;
  }
  Alert.alert('Discard this unfinished record?', 'The draft will be removed from this phone.', [
    { text: 'Keep', style: 'cancel' },
    { text: 'Discard', style: 'destructive', onPress: run },
  ]);
}

function clock(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F4F7F5' },
  scroll: { padding: 20, gap: 16, paddingBottom: 40 },
  lead: { fontSize: 16, lineHeight: 22, color: '#1C2B26', marginBottom: 8 },
  userButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#D5E0DB',
  },
  userName: { fontSize: 17, fontWeight: '600', color: '#143D2E' },
  userMeta: { color: '#5C6F68', marginTop: 4 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  who: { fontSize: 16, color: '#143D2E', fontWeight: '600' },
  link: { color: '#1B6B4A', fontSize: 16 },
  banner: { backgroundColor: '#FFF6E5', borderRadius: 12, padding: 16, gap: 12 },
  bannerTitle: { fontSize: 16, lineHeight: 22, color: '#3F2E10' },
  primary: { backgroundColor: '#1B6B4A', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  primaryText: { color: '#FFFFFF', fontSize: 17, fontWeight: '600' },
  secondary: { borderColor: '#1B6B4A', borderWidth: 1, borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
  secondaryText: { color: '#1B6B4A', fontSize: 16, fontWeight: '600' },
  error: { color: '#8E1B1B', fontSize: 15, lineHeight: 20 },
  discard: { textAlign: 'center', color: '#8E1B1B', fontSize: 16 },
  section: { gap: 8 },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: '#5C6F68', textTransform: 'uppercase' },
  card: { backgroundColor: '#FFFFFF', borderRadius: 12, padding: 14, gap: 4 },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#143D2E' },
  cardMeta: { color: '#5C6F68' },
  cardMessage: { color: '#8E1B1B', marginTop: 4 },
});
