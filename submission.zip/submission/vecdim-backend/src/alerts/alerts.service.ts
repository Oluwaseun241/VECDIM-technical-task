import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { DatabaseService } from '../database/database.service.js';

export interface AlertItem {
  id: string;
  state: string;
  lga: string;
  month: string;
  n_records: number;
  mean_risk: number;
  tier: string;
  pyrethroid_resistance_flag: boolean;
}

@Injectable()
export class AlertsService {
  constructor(private readonly database: DatabaseService) {}

  async list(
    userId: string | undefined,
    filter: { state?: string; lga?: string; from?: string; to?: string },
  ): Promise<AlertItem[]> {
    const user = userId?.trim();
    if (!user) throw new UnauthorizedException('Send the X-User-Id header.');
    const from = monthParam(filter.from, 'from');
    const to = monthParam(filter.to, 'to');

    return this.database.withUser(user, async (client) => {
      const known = await client.query(`SELECT 1 FROM users WHERE user_id = $1`, [user]);
      if ((known.rowCount ?? 0) === 0) {
        throw new UnauthorizedException('Unknown user.');
      }
      const result = await client.query<{
        id: string;
        state: string;
        lga: string;
        month: string;
        n_records: number;
        mean_risk: string;
        tier: string;
        pyrethroid_resistance_flag: boolean;
      }>(
        `SELECT id, state, lga, month, n_records, mean_risk, tier,
                pyrethroid_resistance_flag
         FROM alerts
         WHERE ($1::text IS NULL OR state = $1)
           AND ($2::text IS NULL OR lga = $2)
           AND ($3::text IS NULL OR month >= $3)
           AND ($4::text IS NULL OR month <= $4)
         ORDER BY month, state, lga`,
        [clean(filter.state) ?? null, clean(filter.lga) ?? null, from, to],
      );
      return result.rows.map((row) => ({
        id: row.id,
        state: row.state,
        lga: row.lga,
        month: row.month,
        n_records: Number(row.n_records),
        mean_risk: Number(row.mean_risk),
        tier: row.tier,
        pyrethroid_resistance_flag: row.pyrethroid_resistance_flag,
      }));
    });
  }
}

function monthParam(value: string | undefined, name: string): string | null {
  const trimmed = clean(value);
  if (!trimmed) return null;
  const month = trimmed.slice(0, 7);
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
    throw new BadRequestException(`${name} must be a month, such as 2026-06.`);
  }
  return month;
}

function clean(value: string | undefined): string | undefined {
  const trimmed = value?.trim();
  return trimmed ? trimmed : undefined;
}
