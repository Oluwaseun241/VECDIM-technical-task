import { Controller, Get, Headers, Query } from '@nestjs/common';
import { AlertsService } from './alerts.service.js';

@Controller('alerts')
export class AlertsController {
  constructor(private readonly alerts: AlertsService) {}

  @Get()
  list(
    @Headers('x-user-id') userId: string | undefined,
    @Query('state') state?: string,
    @Query('lga') lga?: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ) {
    return this.alerts.list(userId, { state, lga, from, to });
  }
}
