import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module.js';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({
    origin: true,
    allowedHeaders: ['Content-Type', 'X-User-Id'],
  });
  app.setGlobalPrefix('api/v1');
  // Bind on all interfaces so a phone on the same Wi‑Fi can sync.
  await app.listen(process.env.PORT ?? 3000, '0.0.0.0');
}
await bootstrap();
