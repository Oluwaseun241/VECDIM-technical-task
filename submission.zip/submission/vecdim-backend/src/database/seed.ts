/**
 * Idempotent seed for the local database.
 *
 * Connects as the postgres superuser so row-level security does not hide
 * other states. A second run inserts nothing.
 *
 *   npm run db:seed
 *
 * Reads the candidate pack: demo users, outputs/cleaned_data.csv, and
 * outputs/alerts.csv. LGA reference points are already loaded by the migration.
 */
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { parseCsv } from '../validation/parse-csv.js';

const RECORD_COLUMNS = [
  'record_id',
  'state',
  'lga',
  'ward',
  'latitude',
  'longitude',
  'collection_date',
  'species',
  'insecticide',
  'n_exposed',
  'n_dead',
  'mortality_pct',
  'larval_density',
  'urban',
  'irs_covered',
  'itn_use_pct',
  'rainfall_mm',
  'temp_c',
  'ndvi',
  'elevation_m',
  'dist_water_km',
  'slide_positivity_pct',
  'high_risk',
  'captured_at',
  'raw_payload',
  'enrichment_pending',
] as const;

export interface SeedCounts {
  total: number;
  inserted: number;
}

export interface SeedReport {
  users: SeedCounts;
  fieldRecords: SeedCounts;
  alerts: SeedCounts;
  tiers: Record<string, number>;
}

export async function seedDatabase(options?: {
  packRoot?: string;
  databaseUrl?: string;
}): Promise<SeedReport> {
  const packRoot = options?.packRoot ?? defaultPackRoot();
  const databaseUrl =
    options?.databaseUrl ??
    process.env.MIGRATE_DATABASE_URL ??
    'postgres://postgres:postgres@127.0.0.1:5432/vecdim';

  const users = parseCsv(readFileSync(path.join(packRoot, 'data/demo_users.csv'), 'utf8'));
  const records = parseCsv(
    readFileSync(path.join(packRoot, 'outputs/cleaned_data.csv'), 'utf8'),
  );
  const alertsPath = path.join(packRoot, 'outputs/alerts.csv');
  let alertsText: string;
  try {
    alertsText = readFileSync(alertsPath, 'utf8');
  } catch {
    throw new Error(
      `Missing ${alertsPath}. From the candidate pack, run: Rscript R/03_rf_model_and_alerts.R data/vecdim_dummy_entomology_data.csv outputs`,
    );
  }
  const alerts = parseCsv(alertsText);

  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await client.query('BEGIN');
    const insertedUsers = await insertUsers(client, users);
    const insertedRecords = await insertRecords(client, records);
    const insertedAlerts = await insertAlerts(client, alerts);
    const report = await readReport(client, {
      users: insertedUsers,
      fieldRecords: insertedRecords,
      alerts: insertedAlerts,
    });
    await client.query('COMMIT');
    return report;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    await client.end();
  }
}

async function insertUsers(
  client: pg.Client,
  rows: Array<Record<string, string | null>>,
): Promise<number> {
  if (rows.length === 0) return 0;
  const values: Array<string | null> = [];
  const tuples = rows.map((row, index) => {
    const base = index * 4;
    values.push(required(row, 'user_id'), required(row, 'name'), required(row, 'role'), cell(row, 'state'));
    return `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4})`;
  });
  const result = await client.query(
    `INSERT INTO users (user_id, name, role, state)
     VALUES ${tuples.join(', ')}
     ON CONFLICT (user_id) DO NOTHING`,
    values,
  );
  return result.rowCount ?? 0;
}

async function insertRecords(
  client: pg.Client,
  rows: Array<Record<string, string | null>>,
): Promise<number> {
  let inserted = 0;
  for (const group of chunks(rows, 200)) {
    const values: unknown[] = [];
    const tuples = group.map((row, rowIndex) => {
      const recordValues = recordValuesFor(row);
      const offset = rowIndex * RECORD_COLUMNS.length;
      values.push(...recordValues);
      const placeholders = RECORD_COLUMNS.map((column, columnIndex) => {
        const param = offset + columnIndex + 1;
        return column === 'raw_payload' ? `$${param}::jsonb` : `$${param}`;
      });
      return `(${placeholders.join(', ')})`;
    });
    const result = await client.query(
      `INSERT INTO field_records (${RECORD_COLUMNS.join(', ')})
       VALUES ${tuples.join(', ')}
       ON CONFLICT (record_id) DO NOTHING`,
      values,
    );
    inserted += result.rowCount ?? 0;
  }
  return inserted;
}

function recordValuesFor(row: Record<string, string | null>): unknown[] {
  const ndvi = cell(row, 'ndvi');
  const rainfall = cell(row, 'rainfall_mm');
  const collectionDate = required(row, 'collection_date');
  const payload: Record<string, string | null> = {};
  for (const [key, value] of Object.entries(row)) {
    payload[key] = value === '' || value === null ? null : value;
  }

  return [
    required(row, 'record_id'),
    required(row, 'state'),
    required(row, 'lga'),
    required(row, 'ward'),
    required(row, 'latitude'),
    required(row, 'longitude'),
    collectionDate,
    required(row, 'species'),
    required(row, 'insecticide'),
    required(row, 'n_exposed'),
    required(row, 'n_dead'),
    cell(row, 'mortality_pct'),
    required(row, 'larval_density'),
    required(row, 'urban'),
    required(row, 'irs_covered'),
    required(row, 'itn_use_pct'),
    rainfall,
    cell(row, 'temp_c'),
    ndvi,
    cell(row, 'elevation_m'),
    cell(row, 'dist_water_km'),
    cell(row, 'slide_positivity_pct'),
    cell(row, 'high_risk'),
    `${collectionDate}T00:00:00Z`,
    JSON.stringify(payload),
    ndvi === null || rainfall === null,
  ];
}

async function insertAlerts(
  client: pg.Client,
  rows: Array<Record<string, string | null>>,
): Promise<number> {
  if (rows.length === 0) return 0;
  let inserted = 0;
  for (const group of chunks(rows, 200)) {
    const values: unknown[] = [];
    const tuples = group.map((row, rowIndex) => {
      const state = required(row, 'state');
      const lga = required(row, 'lga');
      const month = required(row, 'ym', 'month');
      const offset = rowIndex * 9;
      values.push(
        `${state}|${lga}|${month}`,
        state,
        lga,
        month,
        required(row, 'n', 'n_records'),
        required(row, 'mean_p_high', 'mean_risk'),
        required(row, 'alert', 'tier'),
        cell(row, 'mean_pyrethroid_mort'),
        asBoolean(required(row, 'pyrethroid_resistance_flag')),
      );
      return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6}, $${offset + 7}, $${offset + 8}, $${offset + 9})`;
    });
    const result = await client.query(
      `INSERT INTO alerts (
         id, state, lga, month, n_records, mean_risk, tier,
         mean_pyrethroid_mort, pyrethroid_resistance_flag
       ) VALUES ${tuples.join(', ')}
       ON CONFLICT (id) DO NOTHING`,
      values,
    );
    inserted += result.rowCount ?? 0;
  }
  return inserted;
}

async function readReport(
  client: pg.Client,
  inserted: {
    users: number;
    fieldRecords: number;
    alerts: number;
  },
): Promise<SeedReport> {
  const users = await client.query<{ n: number }>('SELECT count(*)::int AS n FROM users');
  const records = await client.query<{ n: number }>(
    `SELECT count(*)::int AS n FROM field_records WHERE record_id LIKE 'VD%'`,
  );
  const alerts = await client.query<{ n: number }>('SELECT count(*)::int AS n FROM alerts');
  const tiers = await client.query<{ tier: string; n: number }>(
    'SELECT tier, count(*)::int AS n FROM alerts GROUP BY tier ORDER BY tier',
  );
  return {
    users: { total: users.rows[0].n, inserted: inserted.users },
    fieldRecords: { total: records.rows[0].n, inserted: inserted.fieldRecords },
    alerts: { total: alerts.rows[0].n, inserted: inserted.alerts },
    tiers: Object.fromEntries(tiers.rows.map((row) => [row.tier, row.n])),
  };
}

function defaultPackRoot(): string {
  if (process.env.PACK_ROOT) return process.env.PACK_ROOT;
  return path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    '../../../VECDIM_Candidate_Pack',
  );
}

function chunks<T>(items: readonly T[], size: number): T[][] {
  const groups: T[][] = [];
  for (let index = 0; index < items.length; index += size) {
    groups.push(items.slice(index, index + size));
  }
  return groups;
}

function cell(row: Record<string, string | null>, key: string): string | null {
  const value = row[key];
  if (value === undefined || value === null || value === '') return null;
  return value;
}

function required(
  row: Record<string, string | null>,
  key: string,
  alternate?: string,
): string {
  const value = cell(row, key) ?? (alternate ? cell(row, alternate) : null);
  if (value === null) {
    const name = alternate ? `${key} or ${alternate}` : key;
    throw new Error(`Seed row is missing ${name} (record ${row.record_id ?? row.user_id ?? 'unknown'})`);
  }
  return value;
}

function asBoolean(value: string): boolean {
  const normalized = value.toLowerCase();
  if (normalized === 'true' || normalized === 't' || normalized === '1') return true;
  if (normalized === 'false' || normalized === 'f' || normalized === '0') return false;
  throw new Error(`Expected true or false, received ${value}`);
}

function printReport(report: SeedReport) {
  const line = (label: string, counts: SeedCounts) =>
    `${label}: ${counts.total} total, ${counts.inserted} inserted`;
  console.log(line('users', report.users));
  console.log(line('field_records', report.fieldRecords));
  console.log(line('alerts', report.alerts));
  console.log(
    `tiers: ${Object.entries(report.tiers)
      .map(([tier, count]) => `${tier} ${count}`)
      .join(', ')}`,
  );
}

const isDirectRun = process.argv[1]
  ? path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
  : false;

if (isDirectRun) {
  seedDatabase()
    .then(printReport)
    .catch((error: unknown) => {
      console.error(error instanceof Error ? error.message : error);
      process.exitCode = 1;
    });
}
