import { Injectable, OnModuleDestroy } from '@nestjs/common';
import pg from 'pg';

@Injectable()
export class DatabaseService implements OnModuleDestroy {
  readonly pool: pg.Pool;

  constructor() {
    this.pool = new pg.Pool({
      connectionString:
        process.env.DATABASE_URL ??
        'postgres://vecdim_app:vecdim_app@127.0.0.1:5432/vecdim',
      max: 5,
    });
  }

  /**
   * Runs fn as vecdim_app with app.user_id set for this transaction only,
   * so row-level security applies and the setting does not leak to the next request.
   */
  async withUser<T>(
    userId: string,
    fn: (client: pg.PoolClient) => Promise<T>,
  ): Promise<T> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(`SELECT set_config('app.user_id', $1, true)`, [userId]);
      const value = await fn(client);
      await client.query('COMMIT');
      return value;
    } catch (error) {
      await client.query('ROLLBACK').catch(() => undefined);
      throw error;
    } finally {
      client.release();
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.pool.end();
  }
}
