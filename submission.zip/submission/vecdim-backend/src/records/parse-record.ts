import { LGA_REFERENCES } from '../validation/reference.js';
import {
  isMissing,
  type EntomologyRecord,
  type ValidationIssue,
} from '../validation/validate-records.js';

const WARDS = [1, 2, 3, 4, 5, 6] as const;
const SPECIES = new Set([
  'An. gambiae s.s.',
  'An. coluzzii',
  'An. arabiensis',
  'An. funestus',
]);
const INSECTICIDES = new Set([
  'Permethrin',
  'Deltamethrin',
  'Alphacypermethrin',
  'Pirimiphos-methyl',
]);

export interface ParsedSubmission {
  raw: Record<string, unknown>;
  record: EntomologyRecord;
  capturedAt: string | null;
  larvalDensity: number | null;
  urban: number | null;
  irsCovered: number | null;
  /** Shape problems the R rules do not name, such as a missing ward. */
  extraIssues: ValidationIssue[];
}

export function parseSubmission(value: unknown): ParsedSubmission {
  const raw =
    value !== null && typeof value === 'object'
      ? (value as Record<string, unknown>)
      : {};
  const issues: ValidationIssue[] = [];
  const larvalDensity = readOptionalNumber(raw.larval_density);
  const urban = readFlag(raw.urban, 'urban', 'Set urban to yes or no.', issues);
  const irsCovered = readFlag(
    raw.irs_covered,
    'irs_covered',
    'Set whether this place had indoor residual spraying in the last 12 months.',
    issues,
  );

  const record: EntomologyRecord = {
    record_id: readText(raw.record_id) ?? '',
    state: readText(raw.state),
    lga: readText(raw.lga),
    ward: readText(raw.ward),
    latitude: readRequiredNumber(raw.latitude, 'latitude', issues),
    longitude: readRequiredNumber(raw.longitude, 'longitude', issues),
    collection_date: readText(raw.collection_date),
    species: readText(raw.species),
    insecticide: readText(raw.insecticide),
    n_exposed: readRequiredNumber(raw.n_exposed, 'n_exposed', issues),
    n_dead: readRequiredNumber(raw.n_dead, 'n_dead', issues),
    itn_use_pct: readOptionalNumber(raw.itn_use_pct),
    ndvi: readOptionalNumber(raw.ndvi),
    rainfall_mm: readOptionalNumber(raw.rainfall_mm),
    temp_c: readOptionalNumber(raw.temp_c),
    slide_positivity_pct: readOptionalNumber(raw.slide_positivity_pct),
    gps_accuracy_m: readOptionalNumber(raw.gps_accuracy_m),
  };

  const capturedAt = readText(raw.captured_at);
  requireText(record.record_id, 'record_id', 'Create the record again so it has an id.', issues);
  requireText(record.ward, 'ward', 'Choose the ward where you collected this sample.', issues);
  requireText(record.collection_date, 'collection_date', 'Choose the collection date.', issues);
  requireText(record.insecticide, 'insecticide', 'Choose the insecticide.', issues);
  requireText(
    capturedAt,
    'captured_at',
    'The phone did not record the capture time. Save the record again.',
    issues,
  );
  requireText(record.lga, 'lga', 'Choose the LGA where you collected this sample.', issues);

  if (record.species && !SPECIES.has(record.species)) {
    issues.push(shapeIssue('species', 'Choose one of the four Anopheles species on the form.'));
  }
  if (record.insecticide && !INSECTICIDES.has(record.insecticide)) {
    issues.push(shapeIssue('insecticide', 'Choose an insecticide from the form list.'));
  }
  if (
    record.n_exposed !== null &&
    (!Number.isInteger(record.n_exposed) || record.n_exposed < 1 || record.n_exposed > 500)
  ) {
    issues.push(shapeIssue('n_exposed', 'n_exposed must be a whole number from 1 to 500.'));
  }
  if (record.n_dead !== null && !Number.isInteger(record.n_dead)) {
    issues.push(shapeIssue('n_dead', 'n_dead must be a whole number from 0 up to n_exposed.'));
  }
  if (larvalDensity === null) {
    issues.push(shapeIssue('larval_density', 'Enter the larval density (larvae per dip).'));
  } else if (!Number.isInteger(larvalDensity) || larvalDensity < 0) {
    issues.push(shapeIssue('larval_density', 'Larval density must be a whole number, 0 or more.'));
  }
  if (
    record.lga &&
    record.ward &&
    !WARDS.some((n) => record.ward === `${record.lga} Ward ${n}`)
  ) {
    issues.push(
      shapeIssue('ward', `Ward must be ${record.lga} Ward 1 through ${record.lga} Ward 6.`),
    );
  }
  if (
    record.lga &&
    !LGA_REFERENCES.some((row) => row.state === record.state && row.lga === record.lga)
  ) {
    issues.push(
      shapeIssue(
        'lga',
        `${record.lga} is not a pilot LGA for ${record.state ?? 'this state'}. Choose a pilot LGA.`,
      ),
    );
  }

  return { raw, record, capturedAt, larvalDensity, urban, irsCovered, extraIssues: issues };
}

function requireText(
  value: string | null,
  field: string,
  message: string,
  issues: ValidationIssue[],
) {
  if (isMissing(value)) issues.push(shapeIssue(field, message));
}

function shapeIssue(field: string, message: string): ValidationIssue {
  return { rule: 'missing_core', field, severity: 'block', message };
}

function readText(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  return trimmed === '' ? null : trimmed;
}

function readRequiredNumber(
  value: unknown,
  field: string,
  issues: ValidationIssue[],
): number | null {
  const parsed = readOptionalNumber(value);
  if (parsed === null) {
    issues.push(shapeIssue(field, `Enter a number for ${field}.`));
  }
  return parsed;
}

function readOptionalNumber(value: unknown): number | null {
  if (value === undefined || value === null || value === '') return null;
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function readFlag(
  value: unknown,
  field: string,
  message: string,
  issues: ValidationIssue[],
): number | null {
  const parsed = readOptionalNumber(value);
  if (parsed === null || (parsed !== 0 && parsed !== 1)) {
    issues.push(shapeIssue(field, message));
    return null;
  }
  return parsed;
}
