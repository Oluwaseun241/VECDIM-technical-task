import { Body, Controller, Get, Headers, HttpCode, Post, Query } from '@nestjs/common';
import { RecordsService } from './records.service.js';

@Controller('records')
export class RecordsController {
  constructor(private readonly records: RecordsService) {}

  @Post('batch')
  @HttpCode(200)
  submitBatch(
    @Headers('x-user-id') userId: string | undefined,
    @Body() body: { records?: unknown },
  ) {
    return this.records.submitBatch(userId, body);
  }

  @Get()
  list(
    @Headers('x-user-id') userId: string | undefined,
    @Query('state') state?: string,
    @Query('lga') lga?: string,
    @Query('since') since?: string,
  ) {
    return this.records.list(userId, { state, lga, since });
  }
}
