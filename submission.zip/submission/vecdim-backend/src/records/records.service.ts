import {
  BadRequestException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import pg from 'pg';
import { RPipelineService, type RFlagRow } from '../analysis/r-pipeline.service.js';
import { DatabaseService } from '../database/database.service.js';
import {
  RULE_SEVERITY,
  issuesFromFlags,
  type EntomologyRecord,
  type SubmissionStatus,
  type ValidationIssue,
} from '../validation/validate-records.js';
import { parseSubmission, type ParsedSubmission } from './parse-record.js';

export interface PublicIssue {
  rule: string;
  field: string;
  message: string;
}

export interface BatchItemResult {
  record_id: string;
  status: SubmissionStatus | 'already_received';
  flags: PublicIssue[];
  errors: PublicIssue[];
}

interface Prepared {
  parsed: ParsedSubmission;
  assessmentStatus: SubmissionStatus;
  issues: ValidationIssue[];
}

@Injectable()
export class RecordsService {
  constructor(
    private readonly database: DatabaseService,
    private readonly pipeline: RPipelineService,
  ) {}

  async submitBatch(
    userId: string | undefined,
    body: { records?: unknown },
  ): Promise<{ results: BatchItemResult[] }> {
    if (!body || !Array.isArray(body.records)) {
      throw new BadRequestException('Body must be { "records": [ ... ] }.');
    }
    const user = requireUserId(userId);
    const parsed = body.records.map((item) => parseSubmission(item));
    const flagged = await this.pipeline.flagsFor(parsed.map((item) => item.record));
    const prepared = parsed.map((item, index) => prepare(item, flagged[index]));

    const outcome = await this.database.withUser(user, async (client) => {
      await assertKnownUser(client, user);
      await attachDuplicateWarnings(client, prepared, (records) =>
        this.pipeline.flagsFor(records),
      );
      const batch = await client.query<{ id: string }>(
        `INSERT INTO sync_batches (user_id) VALUES ($1) RETURNING id`,
        [user],
      );
      const batchId = batch.rows[0].id;
      const results: BatchItemResult[] = [];
      const storedIds = new Set<string>();

      for (const item of prepared) {
        const recordId = item.parsed.record.record_id;
        if (recordId && storedIds.has(recordId)) {
          results.push({
            record_id: recordId,
            status: 'already_received',
            flags: [],
            errors: [],
          });
          continue;
        }
        const result = await persistOne(client, batchId, user, item);
        if (result.status !== 'rejected') storedIds.add(result.record_id);
        results.push(result);
      }
      return { results };
    });
    if (
      outcome.results.some(
        (item) => item.status === 'accepted' || item.status === 'accepted_with_flags',
      )
    ) {
      this.pipeline.schedule('sync');
    }
    return outcome;
  }

  async list(
    userId: string | undefined,
    filter: { state?: string; lga?: string; since?: string },
  ) {
    const user = requireUserId(userId);
    const since = clean(filter.since);
    if (since && Number.isNaN(Date.parse(since))) {
      throw new BadRequestException('since must be a date or timestamp.');
    }
    return this.database.withUser(user, async (client) => {
      await assertKnownUser(client, user);
      const result = await client.query<Record<string, unknown>>(
        `SELECT record_id, state, lga, ward, latitude, longitude, gps_accuracy_m,
                collection_date::text AS collection_date, species, insecticide,
                n_exposed, n_dead, mortality_pct, larval_density, urban, irs_covered,
                itn_use_pct, rainfall_mm, temp_c, ndvi, elevation_m, dist_water_km,
                slide_positivity_pct, captured_at, received_at, enrichment_pending,
                submitted_by
         FROM field_records
         WHERE ($1::text IS NULL OR state = $1)
           AND ($2::text IS NULL OR lga = $2)
           AND ($3::timestamptz IS NULL OR received_at >= $3)
         ORDER BY received_at, record_id`,
        [clean(filter.state) ?? null, clean(filter.lga) ?? null, since ?? null],
      );
      return result.rows.map(presentRecord);
    });
  }
}

function prepare(parsed: ParsedSubmission, flagRow: RFlagRow): Prepared {
  const issues = [
    ...parsed.extraIssues,
    ...issuesFromFlags(parsed.record, flagRow.flags),
  ];
  return {
    parsed,
    assessmentStatus: statusOf(issues),
    issues,
  };
}

async function attachDuplicateWarnings(
  client: pg.PoolClient,
  prepared: Prepared[],
  flagsFor: (records: EntomologyRecord[]) => Promise<RFlagRow[]>,
) {
  const keepers = prepared
    .filter((item) => item.assessmentStatus !== 'rejected')
    .map((item) => item.parsed.record);
  if (keepers.length === 0) return;

  const comparable = keepers.filter(hasDuplicateKey);
  const stored = await loadStoredKeys(client, comparable);
  const flagged = await flagsFor([...stored, ...keepers]);
  const duplicateById = new Map(
    flagged.map((row) => [row.record_id, row.flags.duplicate] as const),
  );

  for (const item of prepared) {
    if (item.assessmentStatus === 'rejected') continue;
    const isDuplicate = duplicateById.get(item.parsed.record.record_id) === true;
    item.issues = item.issues.filter((issue) => issue.rule !== 'duplicate');
    if (isDuplicate) {
      item.issues.push({
        rule: 'duplicate',
        field: 'ward',
        severity: 'warn',
        message:
          'Another record has the same ward, date, species, insecticide, and mosquito counts, and its record ID comes first. Check that this sample was not entered twice. You can still save it.',
      });
    }
    item.assessmentStatus = statusOf(item.issues);
  }
}

async function loadStoredKeys(
  client: pg.PoolClient,
  records: EntomologyRecord[],
): Promise<EntomologyRecord[]> {
  if (records.length === 0) return [];
  const values: unknown[] = [];
  const tuples = records.map((record, index) => {
    const offset = index * 6;
    values.push(
      record.ward,
      record.collection_date,
      record.species,
      record.insecticide,
      record.n_exposed,
      record.n_dead,
    );
    return `($${offset + 1}, $${offset + 2}::date, $${offset + 3}, $${offset + 4}, $${offset + 5}::int, $${offset + 6}::int)`;
  });
  const result = await client.query<{
    record_id: string;
    ward: string;
    collection_date: string;
    species: string;
    insecticide: string;
    n_exposed: number;
    n_dead: number;
  }>(
    `SELECT record_id, ward, collection_date::text AS collection_date,
            species, insecticide, n_exposed, n_dead
     FROM field_record_keys
     WHERE (ward, collection_date, species, insecticide, n_exposed, n_dead)
       IN (${tuples.join(', ')})`,
    values,
  );
  return result.rows.map((row) => ({
    record_id: row.record_id,
    state: null,
    lga: null,
    ward: row.ward,
    latitude: null,
    longitude: null,
    collection_date: row.collection_date,
    species: row.species,
    insecticide: row.insecticide,
    n_exposed: row.n_exposed,
    n_dead: row.n_dead,
    itn_use_pct: null,
  }));
}

async function persistOne(
  client: pg.PoolClient,
  batchId: string,
  userId: string,
  item: Prepared,
): Promise<BatchItemResult> {
  const recordId = item.parsed.record.record_id;
  if (item.assessmentStatus === 'rejected' || recordId === '') {
    return finish(client, batchId, item, 'rejected');
  }

  const existing = await client.query(
    `SELECT 1 FROM field_records WHERE record_id = $1`,
    [recordId],
  );
  if ((existing.rowCount ?? 0) > 0) {
    return finish(client, batchId, item, 'already_received');
  }

  await client.query('SAVEPOINT record_attempt');
  try {
    await insertFieldRecord(client, item, userId);
    await client.query('RELEASE SAVEPOINT record_attempt');
  } catch (error) {
    await client.query('ROLLBACK TO SAVEPOINT record_attempt');
    await client.query('RELEASE SAVEPOINT record_attempt');
    const mapped = mapDbError(error);
    if (mapped === 'already_received') {
      return finish(client, batchId, item, 'already_received');
    }
    if (!mapped) throw error;
    item.issues.push(mapped);
    item.assessmentStatus = 'rejected';
    return finish(client, batchId, item, 'rejected');
  }

  return finish(client, batchId, item, item.assessmentStatus);
}

async function finish(
  client: pg.PoolClient,
  batchId: string,
  item: Prepared,
  status: BatchItemResult['status'],
): Promise<BatchItemResult> {
  const errors =
    status === 'rejected'
      ? item.issues.filter((issue) => issue.severity === 'block').map(publish)
      : [];
  const flags =
    status === 'accepted_with_flags'
      ? item.issues.filter((issue) => issue.severity === 'warn').map(publish)
      : [];

  const inserted = await client.query<{ id: string }>(
    `INSERT INTO sync_batch_items (
       batch_id, record_id, outcome, errors, flags, raw_payload, captured_at
     ) VALUES ($1, $2, $3, $4::jsonb, $5::jsonb, $6::jsonb, $7)
     RETURNING id`,
    [
      batchId,
      item.parsed.record.record_id || 'missing',
      status,
      JSON.stringify(errors),
      JSON.stringify(flags),
      JSON.stringify(item.parsed.raw),
      item.parsed.capturedAt,
    ],
  );

  const loggedIssues =
    status === 'rejected'
      ? item.issues.filter((issue) => issue.severity === 'block')
      : status === 'accepted_with_flags'
        ? item.issues.filter((issue) => issue.severity === 'warn')
        : [];
  for (const issue of loggedIssues) {
    const severity = RULE_SEVERITY[issue.rule];
    if (!severity) continue;
    await client.query(
      `INSERT INTO validation_results (
         sync_batch_item_id, record_id, rule_id, severity, field_name, message
       ) VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        inserted.rows[0].id,
        item.parsed.record.record_id || 'missing',
        issue.rule,
        severity,
        issue.field,
        issue.message,
      ],
    );
  }

  return {
    record_id: item.parsed.record.record_id,
    status,
    flags: status === 'accepted_with_flags' ? flags : [],
    errors: status === 'rejected' ? errors : [],
  };
}

async function insertFieldRecord(
  client: pg.PoolClient,
  item: Prepared,
  userId: string,
) {
  const record = item.parsed.record;
  await client.query(
    `INSERT INTO field_records (
       record_id, state, lga, ward, latitude, longitude, gps_accuracy_m,
       collection_date, species, insecticide, n_exposed, n_dead, mortality_pct,
       larval_density, urban, irs_covered, itn_use_pct,
       ndvi, rainfall_mm, temp_c, slide_positivity_pct,
       captured_at, raw_payload, enrichment_pending, submitted_by
     ) VALUES (
       $1, $2, $3, $4, $5, $6, $7,
       $8, $9, $10, $11, $12, $13,
       $14, $15, $16, $17,
       $18, $19, $20, $21,
       $22, $23::jsonb, $24, $25
     )`,
    [
      record.record_id,
      record.state,
      record.lga,
      record.ward,
      record.latitude,
      record.longitude,
      record.gps_accuracy_m ?? null,
      record.collection_date,
      record.species,
      record.insecticide,
      record.n_exposed,
      record.n_dead,
      mortalityPct(record.n_dead, record.n_exposed),
      item.parsed.larvalDensity,
      item.parsed.urban,
      item.parsed.irsCovered,
      record.itn_use_pct,
      record.ndvi ?? null,
      record.rainfall_mm ?? null,
      record.temp_c ?? null,
      record.slide_positivity_pct ?? null,
      item.parsed.capturedAt,
      JSON.stringify(item.parsed.raw),
      record.ndvi === null ||
        record.ndvi === undefined ||
        record.rainfall_mm === null ||
        record.rainfall_mm === undefined,
      userId,
    ],
  );
}

function mortalityPct(dead: number | null, exposed: number | null): number | null {
  if (dead === null || exposed === null || exposed <= 0) return null;
  return Math.round((1000 * dead) / exposed) / 10;
}

function mapDbError(error: unknown): ValidationIssue | 'already_received' | null {
  if (typeof error !== 'object' || error === null || !('code' in error)) return null;
  const code = String((error as { code: string }).code);
  const constraint =
    'constraint' in error ? String((error as { constraint?: string }).constraint ?? '') : '';
  if (code === '23505') return 'already_received';
  if (code === '42501') {
    return {
      rule: 'GPS_state_mismatch',
      field: 'state',
      severity: 'block',
      message: 'Your account cannot submit a record for this state.',
    };
  }
  if (code === '23503') {
    return {
      rule: 'missing_core',
      field: 'lga',
      severity: 'block',
      message: 'Choose one of the pilot LGAs, then resubmit this record.',
    };
  }
  if (code !== '23514') return null;
  const known = CONSTRAINT_MESSAGES[constraint];
  if (known) return known;
  return {
    rule: 'missing_core',
    field: 'record_id',
    severity: 'block',
    message: 'This record was rejected by a database check. Correct it and resubmit.',
  };
}

const CONSTRAINT_MESSAGES: Record<string, ValidationIssue> = {
  field_records_nigeria: {
    rule: 'GPS_outside_nigeria',
    field: 'latitude',
    severity: 'block',
    message: 'This point is outside Nigeria. Recapture the GPS location.',
  },
  field_records_not_zero_zero: {
    rule: 'GPS_zero_zero',
    field: 'latitude',
    severity: 'block',
    message: 'Latitude and longitude are 0, 0. Recapture the GPS location.',
  },
  field_records_state_box: {
    rule: 'GPS_state_mismatch',
    field: 'latitude',
    severity: 'block',
    message: 'This location is outside the selected state. Recapture the GPS location or choose the correct state.',
  },
  field_records_gps_accuracy: {
    rule: 'GPS_accuracy_unusable',
    field: 'gps_accuracy_m',
    severity: 'block',
    message: 'GPS accuracy is too poor to save. Move to open sky and recapture the location.',
  },
  field_records_counts: {
    rule: 'n_dead_gt_n_exposed',
    field: 'n_dead',
    severity: 'block',
    message: 'n_exposed must be from 1 to 500, and n_dead cannot be greater than n_exposed.',
  },
};

function publish(issue: ValidationIssue): PublicIssue {
  return { rule: issue.rule, field: issue.field, message: issue.message };
}

function statusOf(issues: ValidationIssue[]): SubmissionStatus {
  if (issues.some((issue) => issue.severity === 'block')) return 'rejected';
  if (issues.some((issue) => issue.severity === 'warn')) return 'accepted_with_flags';
  return 'accepted';
}

function hasDuplicateKey(record: EntomologyRecord): boolean {
  return (
    record.ward !== null &&
    record.collection_date !== null &&
    record.species !== null &&
    record.insecticide !== null &&
    record.n_exposed !== null &&
    record.n_dead !== null
  );
}

function requireUserId(userId: string | undefined): string {
  const trimmed = userId?.trim();
  if (!trimmed) {
    throw new UnauthorizedException('Send the X-User-Id header.');
  }
  return trimmed;
}

async function assertKnownUser(client: pg.PoolClient, userId: string) {
  const result = await client.query(`SELECT 1 FROM users WHERE user_id = $1`, [userId]);
  if ((result.rowCount ?? 0) === 0) {
    throw new UnauthorizedException('Unknown user.');
  }
}

function clean(value: string | undefined): string | undefined {
  const trimmed = value?.trim();
  return trimmed ? trimmed : undefined;
}

function presentRecord(row: Record<string, unknown>) {
  return {
    ...row,
    latitude: asNumber(row.latitude),
    longitude: asNumber(row.longitude),
    gps_accuracy_m: asNumber(row.gps_accuracy_m),
    mortality_pct: asNumber(row.mortality_pct),
    itn_use_pct: asNumber(row.itn_use_pct),
    rainfall_mm: asNumber(row.rainfall_mm),
    temp_c: asNumber(row.temp_c),
    ndvi: asNumber(row.ndvi),
    elevation_m: asNumber(row.elevation_m),
    dist_water_km: asNumber(row.dist_water_km),
    slide_positivity_pct: asNumber(row.slide_positivity_pct),
    captured_at: asIso(row.captured_at),
    received_at: asIso(row.received_at),
  };
}

function asNumber(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function asIso(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  if (value instanceof Date) return value.toISOString();
  return String(value);
}
