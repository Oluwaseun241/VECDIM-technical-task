import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  healthCheck(): { status: 'ok' } {
    return { status: 'ok' };
  }
}
