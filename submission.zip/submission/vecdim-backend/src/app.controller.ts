import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service.js';

@Controller('health')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  healthCheck(): { status: 'ok' } {
    return this.appService.healthCheck();
  }
}
