import { spawn } from 'node:child_process';

const CONTAINER = process.env.R_CONTAINER ?? 'vecdim-r';

let cliPromise: Promise<string> | undefined;

export function containerCli(): Promise<string> {
  if (process.env.CONTAINER_CLI) return Promise.resolve(process.env.CONTAINER_CLI);
  cliPromise ??= detectCli();
  return cliPromise;
}

function detectCli(): Promise<string> {
  return new Promise((resolve) => {
    const child = spawn('docker', ['info'], { stdio: 'ignore' });
    child.on('error', () => resolve('podman'));
    child.on('exit', (code) => resolve(code === 0 ? 'docker' : 'podman'));
  });
}

/** Runs a command in the R container. Pass stdin when the command reads it. */
export function execInRContainer(
  command: string[],
  stdin?: string,
  timeoutMs = 60_000,
): Promise<string> {
  return new Promise((resolve, reject) => {
    void containerCli().then((cli) => {
      const child = spawn(cli, ['exec', '-i', '-w', '/pack', CONTAINER, ...command], {
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      const stdout: Buffer[] = [];
      const stderr: Buffer[] = [];
      const timer = setTimeout(() => child.kill('SIGKILL'), timeoutMs);

      child.stdout.on('data', (chunk: Buffer) => stdout.push(chunk));
      child.stderr.on('data', (chunk: Buffer) => stderr.push(chunk));
      child.on('error', (error) => {
        clearTimeout(timer);
        reject(error);
      });
      child.on('exit', (code) => {
        clearTimeout(timer);
        const out = Buffer.concat(stdout).toString('utf8');
        const err = Buffer.concat(stderr).toString('utf8');
        if (code === 0) {
          resolve(out);
          return;
        }
        const detail = err.trim() || out.trim() || `exit ${code}`;
        reject(new Error(containerHint(detail)));
      });

      if (stdin !== undefined) child.stdin.end(stdin);
      else child.stdin.end();
    }, reject);
  });
}

function containerHint(detail: string): string {
  if (detail.includes('no container') || detail.includes('is not running')) {
    return 'The R pipeline container is not running. Start it with npm run analysis:up.';
  }
  return detail;
}
