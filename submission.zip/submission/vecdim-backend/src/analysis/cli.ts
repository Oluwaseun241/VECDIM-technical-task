import { RPipelineService } from './r-pipeline.service.js';

const pipeline = new RPipelineService(null as never);

pipeline
  .runNow()
  .then((report) => {
    console.log(JSON.stringify(report, null, 2));
  })
  .catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  });
