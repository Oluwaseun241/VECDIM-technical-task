/**
 * Re-runs the pack's R/01_validate_and_clean.R on the sample CSV and compares
 * every rule flag to outputs/validation_flags_all.csv.
 *
 * Usage: npm run test:parity
 * Requires: npm run analysis:up (container vecdim-r running)
 */

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execInRContainer } from './r-runner.js';
import { parseCsv } from '../validation/parse-csv.js';
import { PARITY_RULES } from '../validation/validate-records.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const backendRoot = path.resolve(here, '../..');
const packRoot =
  process.env.PACK_ROOT ?? path.resolve(backendRoot, '../VECDIM_Candidate_Pack');
const reportDir = path.join(backendRoot, 'parity');
const reportPath = path.join(reportDir, 'parity-report.json');

const WORK = '/work/parity-check';

async function main() {
  await execInRContainer(['rm', '-rf', WORK]);
  await execInRContainer(['mkdir', '-p', WORK]);
  await execInRContainer(
    [
      'Rscript',
      'R/01_validate_and_clean.R',
      'data/vecdim_dummy_entomology_data.csv',
      WORK,
    ],
    undefined,
    180_000,
  );
  const producedCsv = await execInRContainer(['cat', `${WORK}/validation_flags_all.csv`]);
  const expectedCsv = readFileSync(
    path.join(packRoot, 'outputs/validation_flags_all.csv'),
    'utf8',
  );

  const produced = parseCsv(producedCsv);
  const expected = parseCsv(expectedCsv);
  const diffs: Array<{
    record_id: string;
    rule: string;
    expected: boolean;
    got: boolean;
  }> = [];

  if (produced.length !== expected.length) {
    throw new Error(
      `Row count differs: produced ${produced.length}, expected ${expected.length}.`,
    );
  }

  for (let i = 0; i < expected.length; i += 1) {
    const want = expected[i];
    const got = produced[i];
    const recordId = String(want.record_id ?? got.record_id ?? `row-${i}`);
    if (String(want.record_id) !== String(got.record_id)) {
      diffs.push({
        record_id: recordId,
        rule: 'record_id',
        expected: true,
        got: false,
      });
      continue;
    }
    for (const rule of PARITY_RULES) {
      const expectedFlag = asBool(want[rule]);
      const gotFlag = asBool(got[rule]);
      if (expectedFlag !== gotFlag) {
        diffs.push({
          record_id: recordId,
          rule,
          expected: expectedFlag,
          got: gotFlag,
        });
      }
    }
  }

  const differingRecords = new Set(diffs.map((diff) => diff.record_id));
  const report = {
    generated_at: new Date().toISOString(),
    reference_date: '2026-10-08',
    input_rows: expected.length,
    rules: [...PARITY_RULES],
    differing_cells: diffs.length,
    differing_records: differingRecords.size,
    accepted_max_differing_records: 5,
    pass: differingRecords.size <= 5,
    diffs: diffs.slice(0, 200),
    note:
      'Server validation calls the pack script R/01_validate_and_clean.R. This report checks that path against the committed answer key.',
  };

  mkdirSync(reportDir, { recursive: true });
  writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`);
  writeFileSync(path.join(reportDir, 'produced_flags.csv'), producedCsv);

  console.log(
    `Parity: ${report.input_rows} rows, ${report.differing_records} differing records, ${report.differing_cells} cells.`,
  );
  console.log(`Wrote ${reportPath}`);
  if (!report.pass) {
    process.exitCode = 1;
    console.error(
      `Failed: more than ${report.accepted_max_differing_records} records differ from validation_flags_all.csv.`,
    );
  }
}

function asBool(value: string | null | undefined): boolean {
  if (value === null || value === undefined) return false;
  const token = String(value).trim().toUpperCase();
  return token === 'TRUE' || token === 'T' || token === '1';
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
