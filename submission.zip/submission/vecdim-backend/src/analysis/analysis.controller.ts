import { Controller, Headers, HttpCode, Post } from '@nestjs/common';
import { RPipelineService } from './r-pipeline.service.js';

@Controller('analysis')
export class AnalysisController {
  constructor(private readonly pipeline: RPipelineService) {}

  @Post('run')
  @HttpCode(200)
  run(@Headers('x-user-id') userId: string | undefined) {
    return this.pipeline.runRequested(userId);
  }
}
