import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  ForbiddenException,
  Injectable,
  ServiceUnavailableException,
  UnauthorizedException,
} from '@nestjs/common';
import pg from 'pg';
import { DatabaseService } from '../database/database.service.js';
import { parseCsv } from '../validation/parse-csv.js';
import {
  PARITY_RULES,
  type EntomologyRecord,
  type RuleFlags,
} from '../validation/validate-records.js';
import { execInRContainer } from './r-runner.js';

const RAW_COLUMNS = [
  'record_id',
  'state',
  'lga',
  'ward',
  'latitude',
  'longitude',
  'collection_date',
  'species',
  'insecticide',
  'n_exposed',
  'n_dead',
  'mortality_pct',
  'larval_density',
  'rainfall_mm',
  'temp_c',
  'ndvi',
  'elevation_m',
  'dist_water_km',
  'urban',
  'itn_use_pct',
  'irs_covered',
  'slide_positivity_pct',
  'high_risk',
] as const;

const VALIDATE_COLUMNS = [
  'record_id',
  'state',
  'lga',
  'ward',
  'latitude',
  'longitude',
  'collection_date',
  'species',
  'insecticide',
  'n_exposed',
  'n_dead',
  'slide_positivity_pct',
  'temp_c',
  'rainfall_mm',
  'ndvi',
  'itn_use_pct',
] as const;

/** Same rules as R/01_validate_and_clean.R, with today's date instead of pack REF_DATE. */
const LIVE_VALIDATE_R = `source("R/helpers.R")
args <- commandArgs(trailingOnly = TRUE)
in_file <- args[[1]]
out_dir <- args[[2]]
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
df <- read.csv(in_file, stringsAsFactors = FALSE)
df$collection_date <- as.Date(df$collection_date)
flags <- validate_records(df, ref_date = Sys.Date())
write.csv(flags, file.path(out_dir, "validation_flags_all.csv"), row.names = FALSE)
`;

export interface RFlagRow {
  record_id: string;
  flags: RuleFlags;
}

export interface AnalysisReport {
  trigger: 'sync' | 'request';
  input_rows: number;
  appended_rows: number;
  flagged_rows: number;
  clean_rows: number;
  alert_rows: number;
  tiers: Record<string, number>;
}

@Injectable()
export class RPipelineService {
  private chain: Promise<unknown> = Promise.resolve();

  constructor(private readonly database: DatabaseService) {}

  /**
   * Flags from pack R/helpers.R validate_records(), in the same order as records.
   * Live sync uses Sys.Date() so "future" matches the server clock (and the phone).
   * Parity still runs R/01_validate_and_clean.R with the pack REF_DATE 2026-10-08.
   */
  async flagsFor(records: readonly EntomologyRecord[]): Promise<RFlagRow[]> {
    if (records.length === 0) return [];
    const dir = `/work/batch-${randomUUID()}`;
    let stdout: string;
    try {
      await execInRContainer(
        ['sh', '-c', `mkdir -p ${dir} && cat > ${dir}/input.csv`],
        toCsv(records),
      );
      await execInRContainer(
        ['sh', '-c', `cat > ${dir}/validate_live.R`],
        LIVE_VALIDATE_R,
      );
      await execInRContainer([
        'Rscript',
        `${dir}/validate_live.R`,
        `${dir}/input.csv`,
        dir,
      ]);
      stdout = await execInRContainer(['cat', `${dir}/validation_flags_all.csv`]);
    } catch (error) {
      throw new ServiceUnavailableException(messageOf(error));
    } finally {
      await execInRContainer(['rm', '-rf', dir]).catch(() => undefined);
    }
    const rows = parseCsv(stdout);
    if (rows.length !== records.length) {
      throw new ServiceUnavailableException(
        'The R pipeline returned a different number of rows than it was given.',
      );
    }
    return rows.map((row, index) => readFlagRow(row, records[index].record_id));
  }

  /**
   * After a batch stores records, rebuild cleaned data, risk, and alerts.
   * Set ANALYSIS_ON_SYNC=0 to skip this (the API tests do).
   */
  schedule(trigger: 'sync'): void {
    if (process.env.ANALYSIS_ON_SYNC === '0') return;
    void this.enqueue(trigger).catch((error: unknown) => {
      console.error(messageOf(error));
    });
  }

  /** CLI entry. Skips the role check because it uses the admin connection. */
  runNow(): Promise<AnalysisReport> {
    return this.enqueue('request');
  }

  async runRequested(userId: string | undefined): Promise<AnalysisReport> {
    const user = userId?.trim();
    if (!user) throw new UnauthorizedException('Send the X-User-Id header.');
    await this.assertUniosun(user);
    return this.enqueue('request');
  }

  private enqueue(trigger: AnalysisReport['trigger']): Promise<AnalysisReport> {
    const run = this.chain.then(() => this.execute(trigger));
    this.chain = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  private async execute(trigger: AnalysisReport['trigger']): Promise<AnalysisReport> {
    const admin = new pg.Client({ connectionString: adminUrl() });
    await admin.connect();
    const started = await admin.query<{ id: string }>(
      `INSERT INTO analysis_runs (trigger, status) VALUES ($1, 'running') RETURNING id`,
      [trigger],
    );
    const runId = started.rows[0].id;
    try {
      const dataset = await buildDataset(admin);
      await execInRContainer(['sh', '-c', 'rm -rf /work/outputs && cat > /work/input.csv'], dataset.csv);
      try {
        await execInRContainer(
          ['Rscript', 'R/run_all.R', '/work/input.csv', '/work/outputs'],
          undefined,
          6 * 60_000,
        );
      } catch (error) {
        throw new ServiceUnavailableException(messageOf(error));
      }
      const alertsCsv = await execInRContainer(['cat', '/work/outputs/alerts.csv']);
      const riskCsv = await execInRContainer(['cat', '/work/outputs/risk_predictions.csv']);
      const summaryCsv = await execInRContainer(['cat', '/work/outputs/validation_summary.csv']);
      const cleanedCsv = await execInRContainer(['cat', '/work/outputs/cleaned_data.csv']);
      const report = await replaceResults(admin, {
        trigger,
        inputRows: dataset.inputRows,
        appendedRows: dataset.appendedRows,
        flaggedRows: flaggedCount(summaryCsv),
        cleanRows: parseCsv(cleanedCsv).length,
        alerts: parseCsv(alertsCsv),
        risks: parseCsv(riskCsv),
      });
      await admin.query(
        `UPDATE analysis_runs
         SET status = 'ok', finished_at = now(),
             input_rows = $2, appended_rows = $3, flagged_rows = $4,
             clean_rows = $5, alert_rows = $6, error = NULL
         WHERE id = $1`,
        [
          runId,
          report.input_rows,
          report.appended_rows,
          report.flagged_rows,
          report.clean_rows,
          report.alert_rows,
        ],
      );
      return report;
    } catch (error) {
      await admin.query(
        `UPDATE analysis_runs
         SET status = 'failed', finished_at = now(), error = $2
         WHERE id = $1`,
        [runId, messageOf(error).slice(0, 2000)],
      );
      throw error;
    } finally {
      await admin.end();
    }
  }

  private async assertUniosun(userId: string) {
    await this.database.withUser(userId, async (client) => {
      const result = await client.query<{ role: string }>(
        `SELECT role FROM users WHERE user_id = $1`,
        [userId],
      );
      if (result.rowCount === 0) throw new UnauthorizedException('Unknown user.');
      if (result.rows[0].role !== 'uniosun') {
        throw new ForbiddenException('Only a UNIOSUN user can run the analysis.');
      }
    });
  }
}

function readFlagRow(row: Record<string, string | null>, expectedId: string): RFlagRow {
  if (row.record_id !== expectedId) {
    throw new ServiceUnavailableException(
      `The R pipeline returned ${String(row.record_id)} where ${expectedId} was expected.`,
    );
  }
  const flags = {} as RuleFlags;
  for (const rule of PARITY_RULES) {
    const value = row[rule];
    if (value !== 'TRUE' && value !== 'FALSE') {
      throw new ServiceUnavailableException(`The R pipeline omitted ${rule} for ${expectedId}.`);
    }
    flags[rule] = value === 'TRUE';
  }
  return { record_id: expectedId, flags };
}

function toCsv(records: readonly EntomologyRecord[]): string {
  const lines = records.map((record) =>
    [
      quote(record.record_id),
      textCell(record.state),
      textCell(record.lga),
      textCell(record.ward),
      numberCell(record.latitude),
      numberCell(record.longitude),
      textCell(record.collection_date),
      textCell(record.species),
      textCell(record.insecticide),
      numberCell(record.n_exposed),
      numberCell(record.n_dead),
      numberCell(record.slide_positivity_pct),
      numberCell(record.temp_c),
      numberCell(record.rainfall_mm),
      numberCell(record.ndvi),
      numberCell(record.itn_use_pct),
    ].join(','),
  );
  return `${VALIDATE_COLUMNS.join(',')}\n${lines.join('\n')}\n`;
}

function quote(value: string): string {
  return `"${value.replaceAll('"', '""')}"`;
}

function textCell(value: string | null | undefined): string {
  if (value === null || value === undefined || value === '') return 'NA';
  return quote(value);
}

function numberCell(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return 'NA';
  return String(value);
}

async function buildDataset(admin: pg.Client): Promise<{
  csv: string;
  inputRows: number;
  appendedRows: number;
}> {
  const packFile = path.join(packRoot(), 'data', 'vecdim_dummy_entomology_data.csv');
  const original = await readFile(packFile, 'utf8');
  const known = new Set(parseCsv(original).map((row) => row.record_id));
  const extra = await admin.query<Record<string, unknown>>(
    `SELECT record_id, state, lga, ward,
            latitude::float8 AS latitude, longitude::float8 AS longitude,
            collection_date::text AS collection_date, species, insecticide,
            n_exposed, n_dead, mortality_pct::float8 AS mortality_pct,
            larval_density, rainfall_mm::float8 AS rainfall_mm,
            temp_c::float8 AS temp_c, ndvi::float8 AS ndvi,
            elevation_m::float8 AS elevation_m, dist_water_km::float8 AS dist_water_km,
            urban, itn_use_pct::float8 AS itn_use_pct, irs_covered,
            slide_positivity_pct::float8 AS slide_positivity_pct,
            CASE
              WHEN high_risk IS TRUE THEN 1
              WHEN high_risk IS FALSE THEN 0
              WHEN slide_positivity_pct >= 30 THEN 1
              ELSE 0
            END AS high_risk
     FROM field_records
     WHERE ndvi IS NOT NULL
       AND rainfall_mm IS NOT NULL
       AND temp_c IS NOT NULL
       AND elevation_m IS NOT NULL
       AND dist_water_km IS NOT NULL
       AND mortality_pct IS NOT NULL
       AND slide_positivity_pct IS NOT NULL
     ORDER BY record_id`,
  );
  const added = extra.rows.filter((row) => !known.has(String(row.record_id)));
  const body = original.endsWith('\n') ? original : `${original}\n`;
  const extraLines = added.map((row) => RAW_COLUMNS.map((column) => cell(row[column])).join(','));
  return {
    csv: extraLines.length === 0 ? body : `${body}${extraLines.join('\n')}\n`,
    inputRows: known.size + added.length,
    appendedRows: added.length,
  };
}

async function replaceResults(
  admin: pg.Client,
  input: {
    trigger: AnalysisReport['trigger'];
    inputRows: number;
    appendedRows: number;
    flaggedRows: number;
    cleanRows: number;
    alerts: Array<Record<string, string | null>>;
    risks: Array<Record<string, string | null>>;
  },
): Promise<AnalysisReport> {
  await admin.query('BEGIN');
  try {
    await admin.query('DELETE FROM alerts');
    await admin.query('DELETE FROM risk_predictions');
    await insertAlerts(admin, input.alerts);
    await insertRisks(admin, input.risks);
    await admin.query('COMMIT');
  } catch (error) {
    await admin.query('ROLLBACK');
    throw error;
  }
  const tiers = await admin.query<{ tier: string; n: number }>(
    `SELECT tier, count(*)::int AS n FROM alerts GROUP BY tier`,
  );
  return {
    trigger: input.trigger,
    input_rows: input.inputRows,
    appended_rows: input.appendedRows,
    flagged_rows: input.flaggedRows,
    clean_rows: input.cleanRows,
    alert_rows: input.alerts.length,
    tiers: Object.fromEntries(tiers.rows.map((row) => [row.tier, row.n])),
  };
}

async function insertAlerts(
  admin: pg.Client,
  rows: Array<Record<string, string | null>>,
) {
  for (const group of chunks(rows, 200)) {
    const values: unknown[] = [];
    const tuples = group.map((row, index) => {
      const state = required(row, 'state');
      const lga = required(row, 'lga');
      const month = required(row, 'ym');
      const offset = index * 9;
      values.push(
        `${state}|${lga}|${month}`,
        state,
        lga,
        month,
        required(row, 'n'),
        required(row, 'mean_p_high'),
        required(row, 'alert'),
        blankToNull(row.mean_pyrethroid_mort),
        asBoolean(required(row, 'pyrethroid_resistance_flag')),
      );
      return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6}, $${offset + 7}, $${offset + 8}, $${offset + 9})`;
    });
    await admin.query(
      `INSERT INTO alerts (
         id, state, lga, month, n_records, mean_risk, tier,
         mean_pyrethroid_mort, pyrethroid_resistance_flag
       ) VALUES ${tuples.join(', ')}`,
      values,
    );
  }
}

async function insertRisks(
  admin: pg.Client,
  rows: Array<Record<string, string | null>>,
) {
  for (const group of chunks(rows, 200)) {
    const values: unknown[] = [];
    const tuples = group.map((row, index) => {
      const offset = index * 9;
      values.push(
        required(row, 'record_id'),
        required(row, 'state'),
        required(row, 'lga'),
        required(row, 'ward'),
        required(row, 'latitude'),
        required(row, 'longitude'),
        required(row, 'collection_date'),
        required(row, 'p_high'),
        required(row, 'tier'),
      );
      return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6}, $${offset + 7}::date, $${offset + 8}, $${offset + 9})`;
    });
    await admin.query(
      `INSERT INTO risk_predictions (
         record_id, state, lga, ward, latitude, longitude, collection_date, p_high, tier
       ) VALUES ${tuples.join(', ')}`,
      values,
    );
  }
}

function flaggedCount(summaryCsv: string): number {
  const row = parseCsv(summaryCsv).find((item) => (item.rule ?? '').includes('ANY RULE'));
  const count = Number(row?.records_flagged);
  if (!Number.isFinite(count)) {
    throw new Error('validation_summary.csv has no ANY RULE row.');
  }
  return count;
}

function cell(value: unknown): string {
  if (value === null || value === undefined || value === '') return 'NA';
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : 'NA';
  const text = String(value);
  return /[",\n\r]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function required(row: Record<string, string | null>, key: string): string {
  const value = row[key];
  if (value === null || value === undefined || value === '') {
    throw new Error(`Pipeline output is missing ${key} (record ${row.record_id ?? row.lga ?? 'unknown'}).`);
  }
  return value;
}

function blankToNull(value: string | null | undefined): string | null {
  if (value === null || value === undefined || value === '' || value === 'NA') return null;
  return value;
}

function asBoolean(value: string): boolean {
  const normalized = value.toLowerCase();
  if (normalized === 'true' || normalized === 't' || normalized === '1') return true;
  if (normalized === 'false' || normalized === 'f' || normalized === '0') return false;
  throw new Error(`Expected true or false, received ${value}`);
}

function chunks<T>(items: readonly T[], size: number): T[][] {
  const groups: T[][] = [];
  for (let index = 0; index < items.length; index += size) {
    groups.push(items.slice(index, index + size));
  }
  return groups;
}

function packRoot(): string {
  if (process.env.PACK_ROOT) return process.env.PACK_ROOT;
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../VECDIM_Candidate_Pack');
}

function adminUrl(): string {
  return (
    process.env.MIGRATE_DATABASE_URL ?? 'postgres://postgres:postgres@127.0.0.1:5432/vecdim'
  );
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
