/**
 * Messages for flags returned by R's validate_records().
 * The R pipeline decides which of the eleven rules fired.
 * GPS accuracy is applied here because that pipeline does not compute it.
 */

import { NIGERIA_LAT, STATE_BOXES, LGA_REFERENCES } from './reference.js';

export const PARITY_RULES = [
  'GPS_outside_nigeria',
  'GPS_zero_zero',
  'GPS_state_mismatch',
  'GPS_far_from_lga',
  'n_dead_gt_n_exposed',
  'positivity_out_range',
  'future_date',
  'temp_implausible',
  'rainfall_implausible',
  'duplicate',
  'missing_core',
] as const;

export type ParityRuleId = (typeof PARITY_RULES)[number];

export type AccuracyRuleId = 'GPS_accuracy_poor' | 'GPS_accuracy_unusable';

export type RuleId = ParityRuleId | AccuracyRuleId;

export type Severity = 'block' | 'warn';

export const RULE_SEVERITY: Readonly<Record<RuleId, Severity>> = {
  GPS_outside_nigeria: 'block',
  GPS_zero_zero: 'block',
  GPS_state_mismatch: 'block',
  GPS_far_from_lga: 'warn',
  GPS_accuracy_poor: 'warn',
  GPS_accuracy_unusable: 'block',
  n_dead_gt_n_exposed: 'block',
  positivity_out_range: 'block',
  future_date: 'block',
  temp_implausible: 'block',
  rainfall_implausible: 'block',
  duplicate: 'warn',
  missing_core: 'block',
};

export interface EntomologyRecord {
  record_id: string;
  state: string | null;
  lga: string | null;
  ward: string | null;
  latitude: number | null;
  longitude: number | null;
  collection_date: string | null;
  species: string | null;
  insecticide: string | null;
  n_exposed: number | null;
  n_dead: number | null;
  itn_use_pct: number | null;
  ndvi?: number | null;
  rainfall_mm?: number | null;
  temp_c?: number | null;
  slide_positivity_pct?: number | null;
  /** Null means the phone sent the field with no accuracy value. */
  gps_accuracy_m?: number | null;
}

export type RuleFlags = Record<ParityRuleId, boolean>;

export interface ValidationIssue {
  rule: RuleId;
  field: string;
  severity: Severity;
  message: string;
}

export type SubmissionStatus = 'accepted' | 'accepted_with_flags' | 'rejected';

export function isMissing(value: unknown): boolean {
  return value === null || value === undefined || value === '';
}

export function assessGpsAccuracy(
  accuracyM: number | null | undefined,
): ValidationIssue | null {
  if (accuracyM === undefined) return null;

  if (accuracyM === null || !Number.isFinite(accuracyM) || accuracyM > 50) {
    const reading =
      accuracyM === null || !Number.isFinite(accuracyM) ? null : formatNumber(accuracyM);
    return {
      rule: 'GPS_accuracy_unusable',
      field: 'gps_accuracy_m',
      severity: 'block',
      message:
        reading === null
          ? 'The phone did not report GPS accuracy. Move to open sky and recapture the location.'
          : `GPS accuracy is ${reading} m, which is too poor to save (worse than 50 m). Move to open sky and recapture the location.`,
    };
  }

  if (accuracyM > 10) {
    return {
      rule: 'GPS_accuracy_poor',
      field: 'gps_accuracy_m',
      severity: 'warn',
      message: `GPS accuracy is ${formatNumber(accuracyM)} m. Target is 10 m or better. You can save this record, or move to open sky and recapture.`,
    };
  }

  return null;
}

/**
 * Missing ndvi or rainfall_mm stays off this list. The caller marks enrichment_pending.
 */
export function issuesFromFlags(record: EntomologyRecord, flags: RuleFlags): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  if (flags.GPS_outside_nigeria) {
    issues.push({
      rule: 'GPS_outside_nigeria',
      field: latitudeOut(record) ? 'latitude' : 'longitude',
      severity: 'block',
      message:
        'This point is outside Nigeria (latitude 4 to 14, longitude 2.5 to 15). Recapture the GPS location.',
    });
  }

  if (flags.GPS_zero_zero) {
    issues.push({
      rule: 'GPS_zero_zero',
      field: 'latitude',
      severity: 'block',
      message:
        'Latitude and longitude are 0, 0, which is not a collection site. Recapture the GPS location.',
    });
  }

  if (flags.GPS_state_mismatch) {
    issues.push(stateMismatchIssue(record));
  }

  if (flags.GPS_far_from_lga) {
    issues.push(farFromLgaIssue(record));
  }

  if (flags.n_dead_gt_n_exposed) {
    issues.push({
      rule: 'n_dead_gt_n_exposed',
      field: 'n_dead',
      severity: 'block',
      message: `n_dead (${formatNumber(record.n_dead)}) is more than n_exposed (${formatNumber(record.n_exposed)}). Correct the number of dead mosquitoes.`,
    });
  }

  if (flags.positivity_out_range) {
    issues.push({
      rule: 'positivity_out_range',
      field: 'slide_positivity_pct',
      severity: 'block',
      message: `Slide positivity (${formatNumber(record.slide_positivity_pct)}%) is outside 0 to 100. Correct the percentage.`,
    });
  }

  if (flags.future_date) {
    issues.push({
      rule: 'future_date',
      field: 'collection_date',
      severity: 'block',
      message: `Collection date ${record.collection_date} is in the future. Choose today or an earlier date.`,
    });
  }

  if (flags.temp_implausible) {
    issues.push({
      rule: 'temp_implausible',
      field: 'temp_c',
      severity: 'block',
      message: `Temperature (${formatNumber(record.temp_c)} °C) is outside 10 to 50. Correct the temperature.`,
    });
  }

  if (flags.rainfall_implausible) {
    issues.push({
      rule: 'rainfall_implausible',
      field: 'rainfall_mm',
      severity: 'block',
      message: `Rainfall (${formatNumber(record.rainfall_mm)} mm) is outside 0 to 1500. Correct the rainfall.`,
    });
  }

  if (flags.duplicate) {
    issues.push({
      rule: 'duplicate',
      field: 'ward',
      severity: 'warn',
      message:
        'Another record has the same ward, date, species, insecticide, and mosquito counts, and its record ID comes first. Check that this sample was not entered twice. You can still save it.',
    });
  }

  if (flags.missing_core && isMissing(record.species)) {
    issues.push({
      rule: 'missing_core',
      field: 'species',
      severity: 'block',
      message: 'Species is missing. Choose the mosquito species.',
    });
  }

  if (flags.missing_core && isMissing(record.itn_use_pct)) {
    issues.push({
      rule: 'missing_core',
      field: 'itn_use_pct',
      severity: 'block',
      message: 'ITN use percent is missing. Enter a value from 0 to 100.',
    });
  }

  const accuracy = assessGpsAccuracy(record.gps_accuracy_m);
  if (accuracy) issues.push(accuracy);

  return issues;
}

function stateMismatchIssue(record: EntomologyRecord): ValidationIssue {
  const box = isMissing(record.state) ? undefined : STATE_BOXES[record.state as string];

  if (!box) {
    return {
      rule: 'GPS_state_mismatch',
      field: 'state',
      severity: 'block',
      message: 'State is missing or not one of Lagos, Kano, or Osun. Choose a pilot state.',
    };
  }

  return {
    rule: 'GPS_state_mismatch',
    field: 'latitude',
    severity: 'block',
    message: `This location is outside ${record.state} (latitude ${box.latMin} to ${box.latMax}, longitude ${box.lonMin} to ${box.lonMax}). Recapture the GPS location or choose the correct state.`,
  };
}

function farFromLgaIssue(record: EntomologyRecord): ValidationIssue {
  const known = LGA_REFERENCES.some(
    (row) => row.state === record.state && row.lga === record.lga,
  );
  if (!known) {
    const name = isMissing(record.lga) ? 'The LGA' : String(record.lga);
    return {
      rule: 'GPS_far_from_lga',
      field: 'lga',
      severity: 'warn',
      message: `${name} is not a known pilot LGA. Choose the LGA where you collected this sample, or recapture the location.`,
    };
  }

  return {
    rule: 'GPS_far_from_lga',
    field: 'lga',
    severity: 'warn',
    message: `Your location is more than 25 km from ${record.lga}. Check the LGA, or recapture the location.`,
  };
}

function latitudeOut(record: EntomologyRecord): boolean {
  const lat = record.latitude;
  if (lat === null || !Number.isFinite(lat)) return true;
  return lat < NIGERIA_LAT.min || lat > NIGERIA_LAT.max;
}

function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return 'missing';
  return String(value);
}
