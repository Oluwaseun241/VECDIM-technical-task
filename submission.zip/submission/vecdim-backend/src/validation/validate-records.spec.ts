import { parseCsv } from './parse-csv.js';
import {
  assessGpsAccuracy,
  issuesFromFlags,
  type EntomologyRecord,
  type RuleFlags,
} from './validate-records.js';

const noFlags: RuleFlags = {
  GPS_outside_nigeria: false,
  GPS_zero_zero: false,
  GPS_state_mismatch: false,
  GPS_far_from_lga: false,
  n_dead_gt_n_exposed: false,
  positivity_out_range: false,
  future_date: false,
  temp_implausible: false,
  rainfall_implausible: false,
  duplicate: false,
  missing_core: false,
};

function record(overrides: Partial<EntomologyRecord> = {}): EntomologyRecord {
  return {
    record_id: 'r1',
    state: 'Osun',
    lga: 'Osogbo',
    ward: 'Osogbo Ward 2',
    latitude: 7.77,
    longitude: 4.56,
    collection_date: '2026-10-07',
    species: 'An. gambiae s.s.',
    insecticide: 'Permethrin',
    n_exposed: 100,
    n_dead: 54,
    itn_use_pct: 61.5,
    ndvi: 0.5,
    rainfall_mm: 100,
    gps_accuracy_m: 6,
    ...overrides,
  };
}

describe('parseCsv', () => {
  it('treats the R NA token as missing and keeps quoted text', () => {
    const rows = parseCsv('"record_id","species","notes"\n"r1",NA,"An. gambiae s.s."\n');
    expect(rows).toEqual([{ record_id: 'r1', species: '', notes: 'An. gambiae s.s.' }]);
  });
});

describe('issuesFromFlags', () => {
  it('writes the n_dead message from the flag R returned', () => {
    const issues = issuesFromFlags(record({ n_dead: 120, n_exposed: 100 }), {
      ...noFlags,
      n_dead_gt_n_exposed: true,
    });
    expect(issues).toContainEqual({
      rule: 'n_dead_gt_n_exposed',
      field: 'n_dead',
      severity: 'block',
      message:
        'n_dead (120) is more than n_exposed (100). Correct the number of dead mosquitoes.',
    });
  });

  it('reports the distance rule R already decided', () => {
    const issues = issuesFromFlags(record({ lga: 'Ife Central' }), {
      ...noFlags,
      GPS_far_from_lga: true,
    });
    expect(issues[0].message).toBe(
      'Your location is more than 25 km from Ife Central. Check the LGA, or recapture the location.',
    );
  });

  it('does not turn a missing covariate into an error', () => {
    const issues = issuesFromFlags(record({ ndvi: null, rainfall_mm: null }), {
      ...noFlags,
      missing_core: true,
    });
    expect(issues).toEqual([]);
  });
});

describe('GPS accuracy', () => {
  it.each([
    [10, null],
    [6, null],
    [10.1, 'GPS_accuracy_poor'],
    [50, 'GPS_accuracy_poor'],
    [50.1, 'GPS_accuracy_unusable'],
    [null, 'GPS_accuracy_unusable'],
  ])('classifies %s m', (accuracy, rule) => {
    const issue = assessGpsAccuracy(accuracy);
    expect(issue?.rule ?? null).toBe(rule);
  });

  it('ignores accuracy when the field was not sent', () => {
    expect(assessGpsAccuracy(undefined)).toBeNull();
  });
});
