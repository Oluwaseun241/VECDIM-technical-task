/**
 * State boxes and pilot LGA names used in field-worker messages and the form.
 * Distances and rule flags come from R/helpers.R.
 */

export const NIGERIA_LAT = { min: 4, max: 14 } as const;

export interface StateBox {
  latMin: number;
  latMax: number;
  lonMin: number;
  lonMax: number;
}

export const STATE_BOXES: Readonly<Record<string, StateBox>> = {
  Lagos: { latMin: 6.3, latMax: 6.8, lonMin: 2.7, lonMax: 4.4 },
  Kano: { latMin: 11.5, latMax: 12.6, lonMin: 8.0, lonMax: 9.2 },
  Osun: { latMin: 7.0, latMax: 8.2, lonMin: 4.0, lonMax: 5.0 },
};

export interface LgaReference {
  state: string;
  lga: string;
}

/** Same LGAs as data/lga_reference.csv. Centres live in the R pipeline. */
export const LGA_REFERENCES: readonly LgaReference[] = [
  { state: 'Lagos', lga: 'Ikorodu' },
  { state: 'Lagos', lga: 'Alimosho' },
  { state: 'Lagos', lga: 'Epe' },
  { state: 'Lagos', lga: 'Badagry' },
  { state: 'Lagos', lga: 'Eti-Osa' },
  { state: 'Kano', lga: 'Dala' },
  { state: 'Kano', lga: 'Nasarawa' },
  { state: 'Kano', lga: 'Gwale' },
  { state: 'Kano', lga: 'Tarauni' },
  { state: 'Kano', lga: 'Ungogo' },
  { state: 'Osun', lga: 'Osogbo' },
  { state: 'Osun', lga: 'Ife Central' },
  { state: 'Osun', lga: 'Ilesa East' },
  { state: 'Osun', lga: 'Iwo' },
  { state: 'Osun', lga: 'Ede North' },
];
