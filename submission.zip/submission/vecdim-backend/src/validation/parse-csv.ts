/** Minimal CSV reader for the candidate-pack files (quoted fields). */

export function parseCsv(text: string): Array<Record<string, string | null>> {
  const table = parseRows(text);
  if (table.length === 0) return [];

  const headers = table[0];
  const records: Array<Record<string, string | null>> = [];

  for (let i = 1; i < table.length; i++) {
    const cells = table[i];
    if (cells.every((cell) => cell === null || cell === '')) continue;

    const record: Record<string, string | null> = {};
    for (let c = 0; c < headers.length; c++) {
      const header = headers[c];
      if (!header) continue;
      record[header] = cells[c] ?? null;
    }
    records.push(record);
  }

  return records;
}

function parseRows(text: string): string[][] {
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);

  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];

    if (inQuotes) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += char;
      }
      continue;
    }

    if (char === '"') {
      inQuotes = true;
    } else if (char === ',') {
      row.push(normalizeCell(field));
      field = '';
    } else if (char === '\n') {
      row.push(normalizeCell(field));
      rows.push(row);
      row = [];
      field = '';
    } else if (char !== '\r') {
      field += char;
    }
  }

  if (field.length > 0 || row.length > 0) {
    row.push(normalizeCell(field));
    rows.push(row);
  }

  return rows;
}

function normalizeCell(raw: string): string {
  return raw === 'NA' ? '' : raw;
}
