import { Module } from '@nestjs/common';
import { AnalysisController } from './analysis/analysis.controller.js';
import { RPipelineService } from './analysis/r-pipeline.service.js';
import { AlertsController } from './alerts/alerts.controller.js';
import { AlertsService } from './alerts/alerts.service.js';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';
import { DatabaseService } from './database/database.service.js';
import { RecordsController } from './records/records.controller.js';
import { RecordsService } from './records/records.service.js';

@Module({
  imports: [],
  controllers: [AppController, RecordsController, AlertsController, AnalysisController],
  providers: [AppService, DatabaseService, RPipelineService, RecordsService, AlertsService],
})
export class AppModule {}
