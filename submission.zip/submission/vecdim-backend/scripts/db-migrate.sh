#!/usr/bin/env bash
# Apply db/migrations/*.sql once, in filename order.
# Tracks versions in schema_migrations. Safe to run again.
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=container-cli.sh
source "$root/scripts/container-cli.sh"
cli="$(container_cli)"
container="${VECDIM_DB_CONTAINER:-vecdim-db}"

if ! "$cli" inspect -f '{{.State.Running}}' "$container" 2>/dev/null | grep -qx true; then
  echo "Database container '$container' is not running. Start it with: npm run db:up" >&2
  exit 1
fi

ready=0
for _ in $(seq 1 30); do
  if "$cli" exec "$container" pg_isready -U postgres -d vecdim >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 1
done
if [[ "$ready" -ne 1 ]]; then
  echo "Postgres in '$container' did not become ready." >&2
  exit 1
fi

"$cli" exec -i "$container" psql -U postgres -d vecdim -v ON_ERROR_STOP=1 <<'SQL'
CREATE TABLE IF NOT EXISTS schema_migrations (
  version text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);
SQL

shopt -s nullglob
files=("$root"/db/migrations/*.sql)
if [[ ${#files[@]} -eq 0 ]]; then
  echo "No migrations found in db/migrations" >&2
  exit 1
fi

for file in "${files[@]}"; do
  version="$(basename "$file")"
  already="$("$cli" exec "$container" psql -U postgres -d vecdim -tA \
    -c "SELECT 1 FROM schema_migrations WHERE version = '${version}'")"
  if [[ "$already" == "1" ]]; then
    echo "skip $version"
    continue
  fi
  echo "apply $version"
  {
    cat "$file"
    printf "\nINSERT INTO schema_migrations (version) VALUES ('%s');\n" "$version"
  } | "$cli" exec -i "$container" psql -U postgres -d vecdim -v ON_ERROR_STOP=1 -1 -f -
done

echo "migrations up to date"
