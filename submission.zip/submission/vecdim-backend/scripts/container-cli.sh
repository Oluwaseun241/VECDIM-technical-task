# Shared by the database scripts. Uses Docker when the daemon is reachable,
# and Podman otherwise (rootless Podman is enough to run this compose file).
container_cli() {
  if docker info >/dev/null 2>&1; then
    echo docker
    return
  fi
  if podman info >/dev/null 2>&1; then
    echo podman
    return
  fi
  echo "Docker is not reachable and Podman is not available." >&2
  exit 1
}

compose() {
  local cli
  cli="$(container_cli)"
  if [[ "$cli" == "docker" ]]; then
    docker compose "$@"
    return
  fi

  # Podman borrows the docker-compose plugin, which still reads Docker's
  # credential helper. Ignore that helper so a local image can start.
  if [[ -z "${DOCKER_CONFIG:-}" ]]; then
    local empty="${XDG_RUNTIME_DIR:-/tmp}/vecdim-docker-config"
    mkdir -p "$empty"
    if [[ ! -f "$empty/config.json" ]]; then
      printf '{}\n' > "$empty/config.json"
    fi
    DOCKER_CONFIG="$empty" podman compose "$@"
    return
  fi
  podman compose "$@"
}
