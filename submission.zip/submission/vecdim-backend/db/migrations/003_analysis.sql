-- Results of the R pipeline. The admin connection replaces these rows after each run.
-- vecdim_app can read risk points for the states its role allows, same as alerts.

CREATE TABLE risk_predictions (
  record_id text PRIMARY KEY,
  state text NOT NULL,
  lga text NOT NULL,
  ward text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  collection_date date NOT NULL,
  p_high numeric(4, 3) NOT NULL,
  tier text NOT NULL CHECK (tier IN ('ALERT', 'WARNING', 'WATCH')),
  geom geometry(Point, 4326) NOT NULL,
  CONSTRAINT risk_predictions_lga_fk
    FOREIGN KEY (state, lga) REFERENCES lga_reference (state, lga),
  CONSTRAINT risk_predictions_geom_matches CHECK (
    ST_SRID(geom) = 4326
    AND ST_X(geom) = longitude
    AND ST_Y(geom) = latitude
  )
);

CREATE TRIGGER risk_predictions_set_geom
  BEFORE INSERT OR UPDATE OF latitude, longitude ON risk_predictions
  FOR EACH ROW
  EXECUTE FUNCTION field_records_set_geom();

CREATE INDEX risk_predictions_geom_gix ON risk_predictions USING GIST (geom);
CREATE INDEX risk_predictions_state_idx ON risk_predictions (state, lga);

ALTER TABLE risk_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_predictions FORCE ROW LEVEL SECURITY;

CREATE POLICY risk_predictions_select ON risk_predictions
  FOR SELECT
  USING (app_can_see_state(state));

GRANT SELECT ON risk_predictions TO vecdim_app;

CREATE TABLE analysis_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger text NOT NULL CHECK (trigger IN ('sync', 'request')),
  status text NOT NULL CHECK (status IN ('running', 'ok', 'failed')),
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  input_rows integer,
  appended_rows integer,
  flagged_rows integer,
  clean_rows integer,
  alert_rows integer,
  error text
);

COMMENT ON TABLE analysis_runs IS
  'One row per R pipeline run. sync means a batch stored new records. request means POST /analysis/run.';
