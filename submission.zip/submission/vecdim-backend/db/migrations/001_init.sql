-- VECDIM schema.
--
-- users 1—n field_records via submitted_by (null only for historical seed rows).
-- users 1—n sync_batches. A batch has many sync_batch_items, one per record attempt.
-- sync_batch_items 1—n validation_results (every Block or Warn rule on that attempt).
-- lga_reference 1—n field_records and 1—n alerts.
-- alerts are loaded from the R pipeline. tier and pyrethroid_resistance_flag are separate.
--
-- An accepted record is one row in field_records, unique on the phone's record_id.
-- A rejected attempt is stored only in the sync log, so the same record_id can be
-- inserted later once the field worker corrects it.
--
-- The API connects as vecdim_app (not the postgres superuser) so row-level security
-- applies. Superusers bypass RLS even when it is forced.
-- Demo password below is for this local exercise only.

CREATE EXTENSION IF NOT EXISTS postgis;

CREATE ROLE vecdim_app
  LOGIN
  PASSWORD 'vecdim_app'
  NOSUPERUSER
  NOBYPASSRLS
  NOCREATEDB
  NOCREATEROLE;

ALTER ROLE vecdim_app SET search_path = public;
GRANT CONNECT ON DATABASE vecdim TO vecdim_app;
GRANT USAGE ON SCHEMA public TO vecdim_app;

-- ---------------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------------

CREATE TABLE users (
  user_id text PRIMARY KEY,
  name text NOT NULL,
  role text NOT NULL CHECK (role IN ('field', 'vecdim', 'uniosun')),
  state text,
  CONSTRAINT users_role_state CHECK (
    (role = 'uniosun' AND state IS NULL)
    OR (role IN ('field', 'vecdim') AND state IN ('Lagos', 'Kano', 'Osun'))
  )
);

COMMENT ON TABLE users IS
  'Demo accounts. field and vecdim cover one state; uniosun is national and has no state.';

-- ---------------------------------------------------------------------------
-- LGA reference points (the 25 km warning). Loaded here because the GPS rule
-- and the foreign keys depend on this list. Source: data/lga_reference.csv.
-- ---------------------------------------------------------------------------

CREATE TABLE lga_reference (
  state text NOT NULL CHECK (state IN ('Lagos', 'Kano', 'Osun')),
  lga text NOT NULL,
  ref_lat double precision NOT NULL,
  ref_lon double precision NOT NULL,
  max_km integer NOT NULL DEFAULT 25 CHECK (max_km > 0),
  geom geometry(Point, 4326) NOT NULL,
  PRIMARY KEY (state, lga),
  CONSTRAINT lga_reference_geom_matches CHECK (
    ST_SRID(geom) = 4326
    AND ST_X(geom) = ref_lon
    AND ST_Y(geom) = ref_lat
  )
);

CREATE FUNCTION lga_reference_set_geom()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.geom := ST_SetSRID(ST_MakePoint(NEW.ref_lon, NEW.ref_lat), 4326);
  RETURN NEW;
END;
$$;

CREATE TRIGGER lga_reference_set_geom
  BEFORE INSERT OR UPDATE OF ref_lat, ref_lon ON lga_reference
  FOR EACH ROW
  EXECUTE FUNCTION lga_reference_set_geom();

INSERT INTO lga_reference (state, lga, ref_lat, ref_lon) VALUES
  ('Lagos', 'Ikorodu', 6.62, 3.51),
  ('Lagos', 'Alimosho', 6.60, 3.25),
  ('Lagos', 'Epe', 6.58, 3.98),
  ('Lagos', 'Badagry', 6.43, 2.88),
  ('Lagos', 'Eti-Osa', 6.45, 3.60),
  ('Kano', 'Dala', 12.00, 8.52),
  ('Kano', 'Nasarawa', 12.00, 8.55),
  ('Kano', 'Gwale', 11.98, 8.49),
  ('Kano', 'Tarauni', 11.97, 8.54),
  ('Kano', 'Ungogo', 12.05, 8.48),
  ('Osun', 'Osogbo', 7.77, 4.56),
  ('Osun', 'Ife Central', 7.48, 4.56),
  ('Osun', 'Ilesa East', 7.62, 4.73),
  ('Osun', 'Iwo', 7.63, 4.18),
  ('Osun', 'Ede North', 7.74, 4.43);

CREATE INDEX lga_reference_geom_gix ON lga_reference USING GIST (geom);

-- ---------------------------------------------------------------------------
-- Accepted field records. Rejected attempts are not stored here.
-- Block rules from validation_rules.md are CHECKs where PostgreSQL allows it.
-- future_date is not a CHECK: CURRENT_DATE is not immutable.
-- duplicate is a warning, so the natural key is intentionally not unique.
-- gps_accuracy_m is nullable because cleaned historical rows have no phone accuracy.
-- ---------------------------------------------------------------------------

CREATE TABLE field_records (
  record_id text PRIMARY KEY,
  state text NOT NULL,
  lga text NOT NULL,
  ward text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  gps_accuracy_m double precision,
  collection_date date NOT NULL,
  species text NOT NULL,
  insecticide text NOT NULL,
  n_exposed integer NOT NULL,
  n_dead integer NOT NULL,
  mortality_pct numeric(5, 1),
  larval_density integer NOT NULL,
  urban smallint NOT NULL,
  irs_covered smallint NOT NULL,
  itn_use_pct numeric(5, 1) NOT NULL,
  rainfall_mm numeric(6, 1),
  temp_c numeric(4, 1),
  ndvi numeric(4, 3),
  elevation_m numeric(7, 1),
  dist_water_km numeric(6, 2),
  slide_positivity_pct numeric(5, 1),
  high_risk boolean,
  captured_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  raw_payload jsonb NOT NULL,
  enrichment_pending boolean NOT NULL,
  submitted_by text REFERENCES users (user_id),
  geom geometry(Point, 4326) NOT NULL,
  CONSTRAINT field_records_lga_fk
    FOREIGN KEY (state, lga) REFERENCES lga_reference (state, lga),
  CONSTRAINT field_records_nigeria CHECK (
    latitude BETWEEN 4 AND 14
    AND longitude BETWEEN 2.5 AND 15
  ),
  CONSTRAINT field_records_not_zero_zero CHECK (
    NOT (latitude = 0 AND longitude = 0)
  ),
  CONSTRAINT field_records_state_box CHECK (
    (state = 'Lagos' AND latitude BETWEEN 6.3 AND 6.8 AND longitude BETWEEN 2.7 AND 4.4)
    OR (state = 'Kano' AND latitude BETWEEN 11.5 AND 12.6 AND longitude BETWEEN 8.0 AND 9.2)
    OR (state = 'Osun' AND latitude BETWEEN 7.0 AND 8.2 AND longitude BETWEEN 4.0 AND 5.0)
  ),
  CONSTRAINT field_records_gps_accuracy CHECK (
    gps_accuracy_m IS NULL
    OR (gps_accuracy_m >= 0 AND gps_accuracy_m <= 50)
  ),
  CONSTRAINT field_records_counts CHECK (
    n_exposed BETWEEN 1 AND 500
    AND n_dead BETWEEN 0 AND n_exposed
  ),
  CONSTRAINT field_records_species CHECK (
    species IN (
      'An. gambiae s.s.',
      'An. coluzzii',
      'An. arabiensis',
      'An. funestus'
    )
  ),
  CONSTRAINT field_records_insecticide CHECK (
    insecticide IN (
      'Permethrin',
      'Deltamethrin',
      'Alphacypermethrin',
      'Pirimiphos-methyl'
    )
  ),
  CONSTRAINT field_records_larval CHECK (larval_density >= 0),
  CONSTRAINT field_records_flags CHECK (
    urban IN (0, 1)
    AND irs_covered IN (0, 1)
  ),
  CONSTRAINT field_records_itn CHECK (itn_use_pct BETWEEN 0 AND 100),
  CONSTRAINT field_records_mortality CHECK (
    mortality_pct IS NULL OR mortality_pct BETWEEN 0 AND 100
  ),
  CONSTRAINT field_records_positivity CHECK (
    slide_positivity_pct IS NULL
    OR slide_positivity_pct BETWEEN 0 AND 100
  ),
  CONSTRAINT field_records_temp CHECK (
    temp_c IS NULL OR temp_c BETWEEN 10 AND 50
  ),
  CONSTRAINT field_records_rainfall CHECK (
    rainfall_mm IS NULL OR rainfall_mm BETWEEN 0 AND 1500
  ),
  CONSTRAINT field_records_enrichment CHECK (
    enrichment_pending = (ndvi IS NULL OR rainfall_mm IS NULL)
  ),
  CONSTRAINT field_records_ward CHECK (
    ward = ANY (ARRAY[
      lga || ' Ward 1',
      lga || ' Ward 2',
      lga || ' Ward 3',
      lga || ' Ward 4',
      lga || ' Ward 5',
      lga || ' Ward 6'
    ])
  ),
  CONSTRAINT field_records_geom_matches CHECK (
    ST_SRID(geom) = 4326
    AND ST_X(geom) = longitude
    AND ST_Y(geom) = latitude
  )
);

COMMENT ON TABLE field_records IS
  'One accepted submission. Phone record_id is unique. Payload, device time, and server time are kept.';
COMMENT ON COLUMN field_records.raw_payload IS
  'JSON body exactly as received for the attempt that was accepted.';
COMMENT ON COLUMN field_records.enrichment_pending IS
  'True when ndvi or rainfall_mm is still null. Those covariates are added by the server, not the form.';

CREATE FUNCTION field_records_set_geom()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.geom := ST_SetSRID(ST_MakePoint(NEW.longitude, NEW.latitude), 4326);
  RETURN NEW;
END;
$$;

CREATE TRIGGER field_records_set_geom
  BEFORE INSERT OR UPDATE OF latitude, longitude ON field_records
  FOR EACH ROW
  EXECUTE FUNCTION field_records_set_geom();

CREATE INDEX field_records_geom_gix ON field_records USING GIST (geom);
CREATE INDEX field_records_state_received_at_idx
  ON field_records (state, received_at);
CREATE INDEX field_records_submitted_by_idx ON field_records (submitted_by);
CREATE INDEX field_records_lga_idx ON field_records (state, lga);

-- ---------------------------------------------------------------------------
-- Sync log. Every attempt is kept, including rejected ones and their errors.
-- ---------------------------------------------------------------------------

CREATE TABLE sync_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES users (user_id),
  received_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX sync_batches_user_received_at_idx
  ON sync_batches (user_id, received_at);

CREATE TABLE sync_batch_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id uuid NOT NULL REFERENCES sync_batches (id) ON DELETE CASCADE,
  record_id text NOT NULL,
  outcome text NOT NULL CHECK (
    outcome IN ('accepted', 'accepted_with_flags', 'rejected', 'already_received')
  ),
  errors jsonb NOT NULL DEFAULT '[]'::jsonb,
  flags jsonb NOT NULL DEFAULT '[]'::jsonb,
  raw_payload jsonb NOT NULL,
  captured_at timestamptz,
  received_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (batch_id, record_id),
  CONSTRAINT sync_batch_items_errors_array CHECK (jsonb_typeof(errors) = 'array'),
  CONSTRAINT sync_batch_items_flags_array CHECK (jsonb_typeof(flags) = 'array')
);

CREATE INDEX sync_batch_items_record_id_idx ON sync_batch_items (record_id);

COMMENT ON TABLE sync_batch_items IS
  'One outcome per record per batch. A rejected record_id has no field_records row, so a later attempt may insert it.';

CREATE TABLE validation_results (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sync_batch_item_id uuid NOT NULL
    REFERENCES sync_batch_items (id) ON DELETE CASCADE,
  record_id text NOT NULL,
  rule_id text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('block', 'warn')),
  field_name text NOT NULL,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT validation_results_rule_severity CHECK (
    (
      severity = 'block'
      AND rule_id IN (
        'GPS_outside_nigeria',
        'GPS_zero_zero',
        'GPS_state_mismatch',
        'GPS_accuracy_unusable',
        'n_dead_gt_n_exposed',
        'positivity_out_range',
        'future_date',
        'temp_implausible',
        'rainfall_implausible',
        'missing_core'
      )
    )
    OR (
      severity = 'warn'
      AND rule_id IN ('GPS_far_from_lga', 'GPS_accuracy_poor', 'duplicate')
    )
  )
);

CREATE INDEX validation_results_record_id_idx ON validation_results (record_id);
CREATE INDEX validation_results_item_idx ON validation_results (sync_batch_item_id);

COMMENT ON TABLE validation_results IS
  'One row per rule that fired on an attempt. Block rules are not copied onto field_records because that row is not stored.';

-- ---------------------------------------------------------------------------
-- Alerts from the R pipeline. Resistance does not change the tier.
-- month is YYYY-MM. id is state|lga|month, matching the API.
-- ---------------------------------------------------------------------------

CREATE TABLE alerts (
  id text PRIMARY KEY,
  state text NOT NULL CHECK (state IN ('Lagos', 'Kano', 'Osun')),
  lga text NOT NULL,
  month text NOT NULL CHECK (month ~ '^[0-9]{4}-(0[1-9]|1[0-2])$'),
  n_records integer NOT NULL CHECK (n_records >= 1),
  mean_risk numeric(4, 3) NOT NULL,
  tier text NOT NULL CHECK (tier IN ('ALERT', 'WARNING', 'WATCH')),
  mean_pyrethroid_mort numeric(5, 1),
  pyrethroid_resistance_flag boolean NOT NULL,
  CONSTRAINT alerts_lga_fk
    FOREIGN KEY (state, lga) REFERENCES lga_reference (state, lga),
  CONSTRAINT alerts_id_shape CHECK (
    id = state || '|' || lga || '|' || month
  ),
  CONSTRAINT alerts_natural_key UNIQUE (state, lga, month),
  CONSTRAINT alerts_tier_matches_risk CHECK (
    (tier = 'ALERT' AND mean_risk >= 0.70)
    OR (tier = 'WARNING' AND mean_risk >= 0.50 AND mean_risk < 0.70)
    OR (tier = 'WATCH' AND mean_risk < 0.50)
  ),
  CONSTRAINT alerts_resistance_matches_mortality CHECK (
    pyrethroid_resistance_flag = (
      mean_pyrethroid_mort IS NOT NULL AND mean_pyrethroid_mort < 90
    )
  )
);

CREATE INDEX alerts_state_month_idx ON alerts (state, month);

COMMENT ON TABLE alerts IS
  'LGA-month early warnings. tier comes from mean risk. pyrethroid_resistance_flag is a separate column.';

-- security_invoker so a vecdim user aggregating this view still hits alerts RLS.
CREATE VIEW alert_tier_counts
WITH (security_invoker = true) AS
SELECT state, tier, count(*)::integer AS n
FROM alerts
GROUP BY state, tier;

COMMENT ON VIEW alert_tier_counts IS
  'Tier counts for the rows the current role can see. UNIOSUN totals are SUM(n) GROUP BY tier.';

-- ---------------------------------------------------------------------------
-- Row-level security.
-- field: own field_records and own sync batches. No alerts.
-- vecdim: records, sync logs, and alerts for their one state.
-- uniosun: everything.
-- A missing app.user_id matches nobody.
-- ---------------------------------------------------------------------------

CREATE FUNCTION app_current_user_id()
RETURNS text
LANGUAGE sql
STABLE
AS $$
  SELECT nullif(current_setting('app.user_id', true), '')
$$;

CREATE FUNCTION app_can_see_state(row_state text)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM users AS me
    WHERE me.user_id = app_current_user_id()
      AND (
        me.role = 'uniosun'
        OR (me.role = 'vecdim' AND me.state = row_state)
      )
  )
$$;

ALTER TABLE field_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE field_records FORCE ROW LEVEL SECURITY;
ALTER TABLE sync_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_batches FORCE ROW LEVEL SECURITY;
ALTER TABLE sync_batch_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_batch_items FORCE ROW LEVEL SECURITY;
ALTER TABLE validation_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE validation_results FORCE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts FORCE ROW LEVEL SECURITY;

CREATE POLICY field_records_select ON field_records
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM users AS me
      WHERE me.user_id = app_current_user_id()
        AND (
          me.role = 'uniosun'
          OR (me.role = 'vecdim' AND me.state = field_records.state)
          OR (me.role = 'field' AND me.user_id = field_records.submitted_by)
        )
    )
  );

CREATE POLICY field_records_insert ON field_records
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM users AS me
      WHERE me.user_id = app_current_user_id()
        AND field_records.submitted_by = me.user_id
        AND (
          me.role = 'uniosun'
          OR me.role = 'field'
          OR (me.role = 'vecdim' AND me.state = field_records.state)
        )
    )
  );

CREATE POLICY sync_batches_select ON sync_batches
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM users AS me
      JOIN users AS owner ON owner.user_id = sync_batches.user_id
      WHERE me.user_id = app_current_user_id()
        AND (
          me.role = 'uniosun'
          OR (me.role = 'field' AND me.user_id = sync_batches.user_id)
          OR (me.role = 'vecdim' AND owner.state = me.state)
        )
    )
  );

CREATE POLICY sync_batches_insert ON sync_batches
  FOR INSERT
  WITH CHECK (user_id = app_current_user_id());

CREATE POLICY sync_batch_items_select ON sync_batch_items
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM sync_batches AS batch
      WHERE batch.id = sync_batch_items.batch_id
    )
  );

CREATE POLICY sync_batch_items_insert ON sync_batch_items
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM sync_batches AS batch
      WHERE batch.id = sync_batch_items.batch_id
        AND batch.user_id = app_current_user_id()
    )
  );

CREATE POLICY validation_results_select ON validation_results
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM sync_batch_items AS item
      WHERE item.id = validation_results.sync_batch_item_id
    )
  );

CREATE POLICY validation_results_insert ON validation_results
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM sync_batch_items AS item
      JOIN sync_batches AS batch ON batch.id = item.batch_id
      WHERE item.id = validation_results.sync_batch_item_id
        AND batch.user_id = app_current_user_id()
        AND item.record_id = validation_results.record_id
    )
  );

CREATE POLICY alerts_select ON alerts
  FOR SELECT
  USING (app_can_see_state(state));

-- ---------------------------------------------------------------------------
-- Grants. The app can read reference data and write submissions.
-- Alerts are loaded by the admin/seed connection, then only read.
-- ---------------------------------------------------------------------------

GRANT SELECT ON users, lga_reference, alerts, alert_tier_counts TO vecdim_app;
GRANT SELECT, INSERT ON
  field_records,
  sync_batches,
  sync_batch_items,
  validation_results
TO vecdim_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO vecdim_app;
