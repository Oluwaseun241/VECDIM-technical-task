-- Duplicate checks must see every stored record, including rows the caller
-- cannot read under row-level security. The view exposes only the duplicate key.
-- The owner is the migration role, which bypasses row-level security.

CREATE VIEW field_record_keys
WITH (security_invoker = false) AS
SELECT
  record_id,
  ward,
  collection_date,
  species,
  insecticide,
  n_exposed,
  n_dead
FROM field_records;

GRANT SELECT ON field_record_keys TO vecdim_app;
