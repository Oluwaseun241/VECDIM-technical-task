/**
 * Schema checks against a migrated local database.
 */
import pg from 'pg';

const adminUrl =
  process.env.MIGRATE_DATABASE_URL ??
  'postgres://postgres:postgres@127.0.0.1:5432/vecdim';
const appUrl =
  process.env.DATABASE_URL ??
  'postgres://vecdim_app:vecdim_app@127.0.0.1:5432/vecdim';

interface FieldInsert {
  recordId: string;
  state: string;
  lga: string;
  ward: string;
  latitude: number;
  longitude: number;
  submittedBy: string;
  gpsAccuracyM?: number | null;
  nExposed?: number;
  nDead?: number;
  species?: string;
  ndvi?: number | null;
  rainfallMm?: number | null;
  enrichmentPending?: boolean;
}

function row(overrides: FieldInsert): FieldInsert {
  return {
    gpsAccuracyM: 6,
    nExposed: 100,
    nDead: 54,
    species: 'An. gambiae s.s.',
    ndvi: 0.5,
    rainfallMm: 100,
    enrichmentPending: false,
    ...overrides,
  };
}

async function insertRecord(client: pg.Client, input: FieldInsert) {
  const record = row(input);
  await client.query(
    `INSERT INTO field_records (
       record_id, state, lga, ward, latitude, longitude, gps_accuracy_m,
       collection_date, species, insecticide, n_exposed, n_dead,
       larval_density, urban, irs_covered, itn_use_pct,
       ndvi, rainfall_mm, captured_at, raw_payload, enrichment_pending, submitted_by
     ) VALUES (
       $1, $2, $3, $4, $5, $6, $7,
       '2026-10-07', $8, 'Permethrin', $9, $10,
       6, 1, 0, 61.5,
       $11, $12, '2026-10-07T09:14:22Z', $13::jsonb, $14, $15
     )`,
    [
      record.recordId,
      record.state,
      record.lga,
      record.ward,
      record.latitude,
      record.longitude,
      record.gpsAccuracyM ?? null,
      record.species,
      record.nExposed,
      record.nDead,
      record.ndvi ?? null,
      record.rainfallMm ?? null,
      JSON.stringify({ record_id: record.recordId }),
      record.enrichmentPending,
      record.submittedBy,
    ],
  );
}

async function expectConstraint(
  run: () => Promise<unknown>,
  constraint: string,
) {
  try {
    await run();
  } catch (error) {
    const dbError = error as { code?: string; constraint?: string };
    expect(dbError.code).toBe('23514');
    expect(dbError.constraint).toBe(constraint);
    return;
  }
  throw new Error(`expected check constraint ${constraint} to reject the row`);
}

describe('vecdim schema', () => {
  let admin: pg.Client;
  let app: pg.Client;

  beforeAll(async () => {
    admin = new pg.Client({ connectionString: adminUrl });
    app = new pg.Client({ connectionString: appUrl });
    await admin.connect();
    await app.connect();
    await admin.query(`
      INSERT INTO users (user_id, name, role, state) VALUES
        ('u_field_01', 'Field worker 1 (Lagos)', 'field', 'Lagos'),
        ('u_field_03', 'Field worker 3 (Osun)', 'field', 'Osun'),
        ('u_vecdim_lagos', 'VECDIM state user (Lagos)', 'vecdim', 'Lagos'),
        ('u_vecdim_osun', 'VECDIM state user (Osun)', 'vecdim', 'Osun'),
        ('u_uniosun_01', 'UNIOSUN national user', 'uniosun', NULL)
      ON CONFLICT (user_id) DO NOTHING
    `);
    await cleanup();
  });

  afterAll(async () => {
    await cleanup();
    await admin.end();
    await app.end();
  });

  async function cleanup() {
    await admin.query(`
      DELETE FROM sync_batches
      WHERE id IN (
        SELECT batch_id FROM sync_batch_items WHERE record_id LIKE 'schema-test-%'
      )
    `);
    await admin.query(
      `DELETE FROM field_records WHERE record_id LIKE 'schema-test-%'`,
    );
    await admin.query(`DELETE FROM alerts WHERE month = '1999-01'`);
  }

  async function asUser(userId: string) {
    await app.query(`SELECT set_config('app.user_id', $1, false)`, [userId]);
  }

  it('stores an accepted record as a PostGIS point and rejects a second copy', async () => {
    await insertRecord(admin, {
      recordId: 'schema-test-osun-1',
      state: 'Osun',
      lga: 'Osogbo',
      ward: 'Osogbo Ward 2',
      latitude: 7.77,
      longitude: 4.56,
      submittedBy: 'u_field_03',
    });

    const stored = await admin.query<{
      srid: number;
      longitude: number;
      latitude: number;
    }>(
      `SELECT ST_SRID(geom) AS srid, ST_X(geom) AS longitude, ST_Y(geom) AS latitude
       FROM field_records WHERE record_id = 'schema-test-osun-1'`,
    );
    expect(stored.rows[0].srid).toBe(4326);
    expect(stored.rows[0].longitude).toBeCloseTo(4.56, 5);
    expect(stored.rows[0].latitude).toBeCloseTo(7.77, 5);

    await expect(
      insertRecord(admin, {
        recordId: 'schema-test-osun-1',
        state: 'Osun',
        lga: 'Osogbo',
        ward: 'Osogbo Ward 1',
        latitude: 7.78,
        longitude: 4.57,
        submittedBy: 'u_field_03',
      }),
    ).rejects.toMatchObject({ code: '23505' });
  });

  it('rejects block-rule violations inside the database', async () => {
    const base = {
      recordId: 'schema-test-bad',
      state: 'Osun',
      lga: 'Osogbo',
      ward: 'Osogbo Ward 2',
      latitude: 7.77,
      longitude: 4.56,
      submittedBy: 'u_field_03',
    };

    await expectConstraint(
      () => insertRecord(admin, { ...base, nDead: 120, nExposed: 100 }),
      'field_records_counts',
    );
    await expectConstraint(
      () =>
        insertRecord(admin, {
          ...base,
          recordId: 'schema-test-bad-state',
          latitude: 6.6,
          longitude: 3.25,
        }),
      'field_records_state_box',
    );
    await expectConstraint(
      () =>
        insertRecord(admin, {
          ...base,
          recordId: 'schema-test-bad-nigeria',
          state: 'Lagos',
          lga: 'Badagry',
          ward: 'Badagry Ward 1',
          latitude: 1,
          longitude: 3.25,
        }),
      'field_records_nigeria',
    );
    await expectConstraint(
      () => insertRecord(admin, { ...base, gpsAccuracyM: 50.1 }),
      'field_records_gps_accuracy',
    );
    await insertRecord(admin, {
      ...base,
      recordId: 'schema-test-accuracy-50',
      gpsAccuracyM: 50,
    });
    await expectConstraint(
      () => insertRecord(admin, { ...base, species: 'Culex' }),
      'field_records_species',
    );
    await expectConstraint(
      () =>
        insertRecord(admin, {
          ...base,
          ndvi: null,
          rainfallMm: null,
          enrichmentPending: false,
        }),
      'field_records_enrichment',
    );
  });

  it('keeps a valid record when a later record in the same batch fails', async () => {
    await admin.query('BEGIN');
    try {
      await admin.query('SAVEPOINT good_row');
      await insertRecord(admin, {
        recordId: 'schema-test-partial-ok',
        state: 'Osun',
        lga: 'Osogbo',
        ward: 'Osogbo Ward 3',
        latitude: 7.77,
        longitude: 4.56,
        submittedBy: 'u_field_03',
      });
      await admin.query('RELEASE SAVEPOINT good_row');

      await admin.query('SAVEPOINT bad_row');
      await expect(
        insertRecord(admin, {
          recordId: 'schema-test-partial-bad',
          state: 'Osun',
          lga: 'Osogbo',
          ward: 'Osogbo Ward 3',
          latitude: 7.77,
          longitude: 4.56,
          submittedBy: 'u_field_03',
          nDead: 200,
        }),
      ).rejects.toMatchObject({ constraint: 'field_records_counts' });
      await admin.query('ROLLBACK TO SAVEPOINT bad_row');

      const kept = await admin.query<{ n: number }>(
        `SELECT count(*)::int AS n FROM field_records
         WHERE record_id = 'schema-test-partial-ok'`,
      );
      expect(kept.rows[0].n).toBe(1);
    } finally {
      await admin.query('ROLLBACK');
    }
  });

  it('lets a corrected record reuse an id that was only rejected', async () => {
    await asUser('u_field_03');
    const batch = await app.query<{ id: string }>(
      `INSERT INTO sync_batches (user_id) VALUES ('u_field_03') RETURNING id`,
    );
    const batchId = batch.rows[0].id;
    const attempt = await app.query<{ id: string }>(
      `INSERT INTO sync_batch_items (
         batch_id, record_id, outcome, errors, raw_payload, captured_at
       ) VALUES (
         $1, 'schema-test-resubmit', 'rejected',
         $2::jsonb, $3::jsonb, '2026-10-07T09:14:22Z'
       ) RETURNING id`,
      [
        batchId,
        JSON.stringify([
          {
            rule: 'n_dead_gt_n_exposed',
            field: 'n_dead',
            message: 'n_dead (120) is more than n_exposed (100).',
          },
        ]),
        JSON.stringify({ record_id: 'schema-test-resubmit', n_dead: 120 }),
      ],
    );
    await app.query(
      `INSERT INTO validation_results (
         sync_batch_item_id, record_id, rule_id, severity, field_name, message
       ) VALUES ($1, 'schema-test-resubmit', 'n_dead_gt_n_exposed', 'block', 'n_dead', $2)`,
      [attempt.rows[0].id, 'Correct the number of dead mosquitoes.'],
    );

    const storedBefore = await admin.query<{ n: number }>(
      `SELECT count(*)::int AS n FROM field_records WHERE record_id = 'schema-test-resubmit'`,
    );
    expect(storedBefore.rows[0].n).toBe(0);

    await insertRecord(app, {
      recordId: 'schema-test-resubmit',
      state: 'Osun',
      lga: 'Osogbo',
      ward: 'Osogbo Ward 4',
      latitude: 7.77,
      longitude: 4.56,
      submittedBy: 'u_field_03',
      nDead: 40,
    });

    const storedAfter = await admin.query<{ n: number }>(
      `SELECT count(*)::int AS n FROM field_records WHERE record_id = 'schema-test-resubmit'`,
    );
    expect(storedAfter.rows[0].n).toBe(1);
  });

  it('limits each role to its own rows', async () => {
    await insertRecord(admin, {
      recordId: 'schema-test-scope-osun',
      state: 'Osun',
      lga: 'Osogbo',
      ward: 'Osogbo Ward 5',
      latitude: 7.77,
      longitude: 4.56,
      submittedBy: 'u_field_03',
    });
    await insertRecord(admin, {
      recordId: 'schema-test-scope-lagos',
      state: 'Lagos',
      lga: 'Alimosho',
      ward: 'Alimosho Ward 1',
      latitude: 6.6,
      longitude: 3.25,
      submittedBy: 'u_field_01',
    });

    await asUser('u_field_03');
    const own = await app.query<{ record_id: string }>(
      `SELECT record_id FROM field_records WHERE record_id LIKE 'schema-test-scope-%' ORDER BY record_id`,
    );
    expect(own.rows.map((result) => result.record_id)).toEqual([
      'schema-test-scope-osun',
    ]);

    await asUser('u_vecdim_osun');
    const stateRows = await app.query<{ record_id: string }>(
      `SELECT record_id FROM field_records WHERE record_id LIKE 'schema-test-scope-%' ORDER BY record_id`,
    );
    expect(stateRows.rows.map((result) => result.record_id)).toEqual([
      'schema-test-scope-osun',
    ]);

    await asUser('u_uniosun_01');
    const national = await app.query<{ record_id: string }>(
      `SELECT record_id FROM field_records WHERE record_id LIKE 'schema-test-scope-%' ORDER BY record_id`,
    );
    expect(national.rows.map((result) => result.record_id)).toEqual([
      'schema-test-scope-lagos',
      'schema-test-scope-osun',
    ]);

    await app.query(`SELECT set_config('app.user_id', '', false)`);
    const anonymous = await app.query<{ n: number }>(
      `SELECT count(*)::int AS n FROM field_records WHERE record_id LIKE 'schema-test-scope-%'`,
    );
    expect(anonymous.rows[0].n).toBe(0);

    await asUser('u_vecdim_lagos');
    await expect(
      insertRecord(app, {
        recordId: 'schema-test-scope-wrong-state',
        state: 'Osun',
        lga: 'Osogbo',
        ward: 'Osogbo Ward 6',
        latitude: 7.77,
        longitude: 4.56,
        submittedBy: 'u_vecdim_lagos',
      }),
    ).rejects.toMatchObject({ code: '42501' });
  });

  it('keeps alert tier and the resistance flag independent and consistent', async () => {
    await admin.query(`
      INSERT INTO alerts (
        id, state, lga, month, n_records, mean_risk, tier,
        mean_pyrethroid_mort, pyrethroid_resistance_flag
      ) VALUES
        ('Osun|Osogbo|1999-01', 'Osun', 'Osogbo', '1999-01', 4, 0.740, 'ALERT', 80.0, true),
        ('Lagos|Alimosho|1999-01', 'Lagos', 'Alimosho', '1999-01', 2, 0.400, 'WATCH', 96.0, false)
    `);

    await expect(
      admin.query(`
        INSERT INTO alerts (
          id, state, lga, month, n_records, mean_risk, tier,
          mean_pyrethroid_mort, pyrethroid_resistance_flag
        ) VALUES (
          'Kano|Dala|1999-01', 'Kano', 'Dala', '1999-01', 1, 0.400, 'ALERT', 96.0, false
        )
      `),
    ).rejects.toMatchObject({ constraint: 'alerts_tier_matches_risk' });

    await expect(
      admin.query(`
        INSERT INTO alerts (
          id, state, lga, month, n_records, mean_risk, tier,
          mean_pyrethroid_mort, pyrethroid_resistance_flag
        ) VALUES (
          'Kano|Gwale|1999-01', 'Kano', 'Gwale', '1999-01', 1, 0.800, 'ALERT', 96.0, true
        )
      `),
    ).rejects.toMatchObject({ constraint: 'alerts_resistance_matches_mortality' });

    await asUser('u_vecdim_osun');
    const visible = await app.query<{ id: string }>(
      `SELECT id FROM alerts WHERE month = '1999-01' ORDER BY id`,
    );
    expect(visible.rows.map((result) => result.id)).toEqual([
      'Osun|Osogbo|1999-01',
    ]);

    await asUser('u_field_03');
    const fieldAlerts = await app.query<{ n: number }>(
      `SELECT count(*)::int AS n FROM alerts WHERE month = '1999-01'`,
    );
    expect(fieldAlerts.rows[0].n).toBe(0);

    await asUser('u_vecdim_osun');
    const stateCounts = await app.query<{
      state: string;
      tier: string;
      n: number;
    }>(`SELECT state, tier, n FROM alert_tier_counts ORDER BY state, tier`);
    expect(stateCounts.rows).toEqual([
      { state: 'Osun', tier: 'ALERT', n: 1 },
    ]);

    await asUser('u_uniosun_01');
    const national = await app.query<{ tier: string; n: number }>(
      `SELECT tier, sum(n)::int AS n
       FROM alert_tier_counts
       GROUP BY tier
       ORDER BY tier`,
    );
    expect(national.rows).toEqual([
      { tier: 'ALERT', n: 1 },
      { tier: 'WATCH', n: 1 },
    ]);
  });

  it('enables a GiST index and forces row-level security', async () => {
    const indexes = await admin.query<{ indexname: string }>(
      `SELECT indexname FROM pg_indexes
       WHERE tablename = 'field_records' AND indexdef ILIKE '%gist%'`,
    );
    expect(indexes.rows.map((result) => result.indexname)).toContain(
      'field_records_geom_gix',
    );

    const rls = await admin.query<{
      relname: string;
      relrowsecurity: boolean;
      relforcerowsecurity: boolean;
    }>(
      `SELECT relname, relrowsecurity, relforcerowsecurity
       FROM pg_class
       WHERE relname IN (
         'field_records', 'sync_batches', 'sync_batch_items',
         'validation_results', 'alerts'
       )
       ORDER BY relname`,
    );
    expect(rls.rows).toHaveLength(5);
    for (const table of rls.rows) {
      expect(table.relrowsecurity, table.relname).toBe(true);
      expect(table.relforcerowsecurity, table.relname).toBe(true);
    }
  });
});
