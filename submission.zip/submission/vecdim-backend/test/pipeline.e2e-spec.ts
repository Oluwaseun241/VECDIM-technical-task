/**
 * Runs the pack's R pipeline and checks the published totals.
 * Requires `npm run analysis:up` and a migrated database.
 */
process.env.ANALYSIS_ON_SYNC = '0';

import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module.js';

describe('R pipeline', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    app = moduleFixture.createNestApplication();
    app.setGlobalPrefix('api/v1');
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuses a field worker', async () => {
    await request(app.getHttpServer())
      .post('/api/v1/analysis/run')
      .set('X-User-Id', 'u_field_03')
      .expect(403);
  });

  it('rebuilds flags, cleaned rows, risk, and alerts from the dataset', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/v1/analysis/run')
      .set('X-User-Id', 'u_uniosun_01')
      .expect(200);

    expect(response.body).toMatchObject({
      trigger: 'request',
      input_rows: 1525,
      appended_rows: 0,
      flagged_rows: 222,
      clean_rows: 1303,
      alert_rows: 647,
      tiers: { ALERT: 86, WARNING: 135, WATCH: 426 },
    });
  }, 360_000);
});
