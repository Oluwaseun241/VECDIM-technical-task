process.env.ANALYSIS_ON_SYNC = '0';

/**
 * Contract checks for the four API routes, including row-level security.
 * Requires the migrated and seeded database (`npm run db:setup && npm run db:seed`).
 */
import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import pg from 'pg';
import request from 'supertest';
import { AppModule } from '../src/app.module.js';

const adminUrl =
  process.env.MIGRATE_DATABASE_URL ??
  'postgres://postgres:postgres@127.0.0.1:5432/vecdim';

interface BatchResult {
  record_id: string;
  status: string;
  flags: { rule: string; field: string; message: string }[];
  errors: { rule: string; field: string; message: string }[];
}

interface StoredRecord {
  record_id: string;
  state: string;
  submitted_by: string;
  enrichment_pending: boolean;
}

function record(overrides: Record<string, unknown>) {
  return {
    state: 'Osun',
    lga: 'Osogbo',
    ward: 'Osogbo Ward 2',
    latitude: 7.77,
    longitude: 4.56,
    gps_accuracy_m: 6,
    collection_date: '2026-10-07',
    species: 'An. gambiae s.s.',
    insecticide: 'Permethrin',
    n_exposed: 321,
    n_dead: 10,
    larval_density: 6,
    urban: 1,
    irs_covered: 0,
    itn_use_pct: 61.5,
    ndvi: 0.42,
    rainfall_mm: 120,
    temp_c: 28,
    captured_at: '2026-10-07T09:14:22Z',
    ...overrides,
  };
}

async function cleanup() {
  const admin = new pg.Client({ connectionString: adminUrl });
  await admin.connect();
  try {
    await admin.query(
      `DELETE FROM sync_batches
       WHERE id IN (
         SELECT batch_id FROM sync_batch_items WHERE record_id LIKE 'api-test-%'
       )`,
    );
    await admin.query(`DELETE FROM field_records WHERE record_id LIKE 'api-test-%'`);
  } finally {
    await admin.end();
  }
}

describe('API', () => {
  let app: INestApplication;
  let since: string;

  beforeAll(async () => {
    await cleanup();
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    app = moduleFixture.createNestApplication();
    app.setGlobalPrefix('api/v1');
    await app.init();
    since = new Date().toISOString();
  });

  afterAll(async () => {
    await app.close();
    await cleanup();
  });

  function post(userId: string | undefined, records: unknown[]) {
    const call = request(app.getHttpServer()).post('/api/v1/records/batch');
    if (userId) call.set('X-User-Id', userId);
    return call.send({ records });
  }

  it('GET /api/v1/health needs no user', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/health').expect(200);
    expect(response.body).toEqual({ status: 'ok' });
  });

  it('rejects a missing or unknown user', async () => {
    await post(undefined, []).expect(401);
    await post('nobody', []).expect(401);
    await request(app.getHttpServer()).get('/api/v1/records').expect(401);
    await request(app.getHttpServer()).get('/api/v1/alerts').expect(401);
  });

  it('accepts nine records and rejects one without rolling the batch back', async () => {
    const records = [
      ...Array.from({ length: 9 }, (_, index) =>
        record({
          record_id: `api-test-ok-${index + 1}`,
          n_dead: 10 + index,
        }),
      ),
      record({
        record_id: 'api-test-bad',
        ward: 'Osogbo Ward 3',
        collection_date: '2026-10-06',
        n_exposed: 100,
        n_dead: 120,
      }),
    ];

    const response = await post('u_field_03', records).expect(200);
    const results = response.body.results as BatchResult[];
    expect(results).toHaveLength(10);
    expect(results.slice(0, 9).every((item) => item.status === 'accepted')).toBe(true);
    expect(results[9]).toMatchObject({
      record_id: 'api-test-bad',
      status: 'rejected',
      flags: [],
    });
    expect(results[9].errors[0]).toMatchObject({
      rule: 'n_dead_gt_n_exposed',
      field: 'n_dead',
    });
    expect(results[9].errors[0].message).toMatch(
      /^n_dead \(120\) is more than n_exposed \(100\)/,
    );

    const again = await post('u_field_03', [records[0]]).expect(200);
    expect(again.body.results[0].status).toBe('already_received');

    const admin = new pg.Client({ connectionString: adminUrl });
    await admin.connect();
    try {
      const stored = await admin.query(
        `SELECT count(*)::int AS n FROM field_records WHERE record_id = 'api-test-ok-1'`,
      );
      const rejected = await admin.query(
        `SELECT count(*)::int AS n FROM field_records WHERE record_id = 'api-test-bad'`,
      );
      expect(stored.rows[0].n).toBe(1);
      expect(rejected.rows[0].n).toBe(0);
    } finally {
      await admin.end();
    }
  });

  it('stores a corrected resubmit of a rejected id', async () => {
    const response = await post('u_field_03', [
      record({
        record_id: 'api-test-bad',
        ward: 'Osogbo Ward 3',
        collection_date: '2026-10-06',
        n_exposed: 100,
        n_dead: 40,
      }),
    ]).expect(200);
    expect(response.body.results[0].status).toBe('accepted');
  });

  it('warns the later duplicate and still stores it', async () => {
    const shared = {
      ward: 'Osogbo Ward 4',
      collection_date: '2026-10-05',
      n_exposed: 222,
      n_dead: 11,
    };
    const response = await post('u_field_03', [
      record({ record_id: 'api-test-dup-b', ...shared }),
      record({ record_id: 'api-test-dup-a', ...shared }),
    ]).expect(200);
    const byId = new Map(
      (response.body.results as BatchResult[]).map((item) => [item.record_id, item]),
    );
    expect(byId.get('api-test-dup-a')?.status).toBe('accepted');
    expect(byId.get('api-test-dup-b')?.status).toBe('accepted_with_flags');
    expect(byId.get('api-test-dup-b')?.flags.map((flag) => flag.rule)).toEqual(['duplicate']);
  });

  it('stores a point more than 25 km from its LGA with a warning', async () => {
    const response = await post('u_field_03', [
      record({
        record_id: 'api-test-far',
        lga: 'Ife Central',
        ward: 'Ife Central Ward 1',
        latitude: 7.77,
        longitude: 4.56,
        n_exposed: 223,
        n_dead: 12,
      }),
    ]).expect(200);
    const item = response.body.results[0] as BatchResult;
    expect(item.status).toBe('accepted_with_flags');
    expect(item.flags[0].rule).toBe('GPS_far_from_lga');
    expect(item.flags[0].message).toContain('more than 25 km');
    expect(item.flags[0].message).toContain('Ife Central');
  });

  it('rejects a collection date after the server clock', async () => {
    const response = await post('u_field_03', [
      record({
        record_id: 'api-test-future',
        collection_date: '2099-01-01',
        n_exposed: 224,
      }),
    ]).expect(200);
    expect(response.body.results[0].status).toBe('rejected');
    expect(response.body.results[0].errors[0].rule).toBe('future_date');
  });

  it('keeps a Lagos record when the same batch has an Osun record the caller cannot submit', async () => {
    const response = await post('u_vecdim_lagos', [
      record({
        record_id: 'api-test-lagos-ok',
        state: 'Lagos',
        lga: 'Ikorodu',
        ward: 'Ikorodu Ward 1',
        latitude: 6.62,
        longitude: 3.51,
        n_exposed: 225,
      }),
      record({
        record_id: 'api-test-lagos-osun',
        n_exposed: 226,
      }),
    ]).expect(200);
    const byId = new Map(
      (response.body.results as BatchResult[]).map((item) => [item.record_id, item]),
    );
    expect(byId.get('api-test-lagos-ok')?.status).toBe('accepted');
    expect(byId.get('api-test-lagos-osun')?.status).toBe('rejected');
    expect(byId.get('api-test-lagos-osun')?.errors[0].rule).toBe('GPS_state_mismatch');
  });

  it('marks a record for enrichment when ndvi and rainfall are absent', async () => {
    const response = await post('u_field_03', [
      record({
        record_id: 'api-test-enrich',
        ndvi: undefined,
        rainfall_mm: undefined,
        n_exposed: 227,
      }),
    ]).expect(200);
    expect(response.body.results[0].status).toBe('accepted');
    expect(response.body.results[0].errors).toEqual([]);
  });

  it('shows a field worker only their own new rows, and a state officer only that state', async () => {
    const own = await request(app.getHttpServer())
      .get('/api/v1/records')
      .query({ since })
      .set('X-User-Id', 'u_field_03')
      .expect(200);
    const ownRows = own.body as StoredRecord[];
    expect(ownRows.every((row) => row.submitted_by === 'u_field_03')).toBe(true);
    expect(ownRows.map((row) => row.record_id).sort()).toEqual(
      [
        'api-test-ok-1',
        'api-test-ok-2',
        'api-test-ok-3',
        'api-test-ok-4',
        'api-test-ok-5',
        'api-test-ok-6',
        'api-test-ok-7',
        'api-test-ok-8',
        'api-test-ok-9',
        'api-test-bad',
        'api-test-dup-a',
        'api-test-dup-b',
        'api-test-far',
        'api-test-enrich',
      ].sort(),
    );
    expect(ownRows.find((row) => row.record_id === 'api-test-enrich')?.enrichment_pending).toBe(
      true,
    );

    const otherField = await request(app.getHttpServer())
      .get('/api/v1/records')
      .query({ since, state: 'Osun' })
      .set('X-User-Id', 'u_field_01')
      .expect(200);
    expect(otherField.body).toEqual([]);

    const lagosOfficer = await request(app.getHttpServer())
      .get('/api/v1/records')
      .query({ since })
      .set('X-User-Id', 'u_vecdim_lagos')
      .expect(200);
    expect((lagosOfficer.body as StoredRecord[]).map((row) => row.record_id)).toEqual([
      'api-test-lagos-ok',
    ]);
  });

  it('returns every alert to UNIOSUN, one state to VECDIM, and none to a field worker', async () => {
    const all = await request(app.getHttpServer())
      .get('/api/v1/alerts')
      .set('X-User-Id', 'u_uniosun_01')
      .expect(200);
    expect(all.body).toHaveLength(647);
    const tiers = { ALERT: 0, WARNING: 0, WATCH: 0 };
    for (const row of all.body as { tier: keyof typeof tiers }[]) tiers[row.tier] += 1;
    expect(tiers).toEqual({ ALERT: 86, WARNING: 135, WATCH: 426 });

    const osun = await request(app.getHttpServer())
      .get('/api/v1/alerts')
      .set('X-User-Id', 'u_vecdim_osun')
      .expect(200);
    expect(osun.body.length).toBeGreaterThan(0);
    expect(osun.body.length).toBeLessThan(647);
    expect((osun.body as { state: string }[]).every((row) => row.state === 'Osun')).toBe(true);

    const field = await request(app.getHttpServer())
      .get('/api/v1/alerts')
      .set('X-User-Id', 'u_field_03')
      .expect(200);
    expect(field.body).toEqual([]);

    const june = await request(app.getHttpServer())
      .get('/api/v1/alerts')
      .query({ from: '2026-06', to: '2026-06' })
      .set('X-User-Id', 'u_uniosun_01')
      .expect(200);
    expect(june.body.length).toBeGreaterThan(0);
    expect((june.body as { month: string }[]).every((row) => row.month === '2026-06')).toBe(true);
  });
});
