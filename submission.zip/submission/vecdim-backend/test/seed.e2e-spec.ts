/**
 * Loads the candidate pack twice. The second run must insert nothing.
 * Run `npm run db:setup` first, then `npm run test:seed`.
 */
import pg from 'pg';
import { seedDatabase } from '../src/database/seed.js';

const adminUrl =
  process.env.MIGRATE_DATABASE_URL ??
  'postgres://postgres:postgres@127.0.0.1:5432/vecdim';

describe('seed', () => {
  beforeAll(async () => {
    const admin = new pg.Client({ connectionString: adminUrl });
    await admin.connect();
    try {
      await admin.query(
        `DELETE FROM field_records WHERE record_id LIKE 'schema-test-%'`,
      );
      await admin.query(`DELETE FROM alerts WHERE month = '1999-01'`);
    } finally {
      await admin.end();
    }
  });

  it('loads users, cleaned records, and alerts, then changes nothing', async () => {
    const first = await seedDatabase();
    const second = await seedDatabase();

    expect(second.users).toEqual({ total: 7, inserted: 0 });
    expect(second.fieldRecords).toEqual({ total: 1303, inserted: 0 });
    expect(second.alerts).toEqual({ total: 647, inserted: 0 });
    expect(second.tiers).toEqual({ ALERT: 86, WARNING: 135, WATCH: 426 });

    expect(first.users.total).toBe(7);
    expect(first.fieldRecords.total).toBe(1303);
    expect(first.alerts.total).toBe(647);
  }, 30_000);
});