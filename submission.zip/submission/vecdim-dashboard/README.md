# VECDIM dashboard

Simple Next.js role views for field, VECDIM, and UNIOSUN users. Reads alerts and records from the Nest API with the `X-User-Id` header.

## Run

```bash
# API (in another terminal)
cd ../vecdim-backend && npm run db:up && npm run start:dev

# Dashboard
cp .env.example .env.local
npm run dev
```

Open [http://localhost:3001](http://localhost:3001) if port 3000 is taken by the API (`next dev` will pick the next free port, or set `-p 3001`).

Default API base: `http://127.0.0.1:3000/api/v1`.
