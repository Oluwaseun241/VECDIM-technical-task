import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'VECDIM dashboard',
  description: 'Role views for field, VECDIM, and UNIOSUN users',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
