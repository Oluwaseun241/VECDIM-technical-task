'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { fetchAlerts, fetchRecords, type AlertItem, type RecordItem } from '@/lib/api';
import { DEMO_USERS, STATES, type DemoUser } from '@/lib/users';
import styles from './page.module.css';

const DEFAULT_USER = DEMO_USERS.find((user) => user.userId === 'u_uniosun_01') ?? DEMO_USERS[0];

export default function DashboardPage() {
  const [userId, setUserId] = useState(DEFAULT_USER.userId);
  const [stateFilter, setStateFilter] = useState('');
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [records, setRecords] = useState<RecordItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const user = useMemo(
    () => DEMO_USERS.find((row) => row.userId === userId) ?? DEFAULT_USER,
    [userId],
  );

  const load = useCallback(async (active: DemoUser, filterState: string, signal?: AbortSignal) => {
    setLoading(true);
    setError(null);
    setRecords([]);
    setAlerts([]);
    const state =
      active.role === 'uniosun'
        ? filterState || undefined
        : active.role === 'vecdim'
          ? (active.state ?? undefined)
          : undefined;
    try {
      const [nextRecords, nextAlerts] = await Promise.all([
        fetchRecords(active.userId, state, signal),
        active.role === 'field'
          ? Promise.resolve([] as AlertItem[])
          : fetchAlerts(active.userId, state, signal),
      ]);
      if (signal?.aborted) return;
      setRecords(nextRecords);
      setAlerts(nextAlerts);
    } catch (err) {
      if (signal?.aborted || (err instanceof DOMException && err.name === 'AbortError')) return;
      setRecords([]);
      setAlerts([]);
      setError(err instanceof Error ? err.message : 'Could not load dashboard data.');
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void load(user, stateFilter, controller.signal);
    return () => controller.abort();
  }, [load, user, stateFilter]);

  const totals = useMemo(() => {
    const counts = { ALERT: 0, WARNING: 0, WATCH: 0 };
    for (const alert of alerts) {
      if (alert.tier in counts) counts[alert.tier as keyof typeof counts] += 1;
    }
    return counts;
  }, [alerts]);

  return (
    <main className={styles.page}>
      <header className={styles.header}>
        <div>
          <h1 className={styles.brand}>VECDIM dashboard</h1>
          <p className={styles.lead}>
            {user.role === 'field'
              ? 'Your submitted records.'
              : user.role === 'vecdim'
                ? `Alerts and records for ${user.state}.`
                : 'National alerts and records across Lagos, Kano, and Osun.'}
          </p>
        </div>
        <div className={styles.controls}>
          <label className={styles.field}>
            Role
            <select
              className={styles.select}
              value={userId}
              onChange={(event) => {
                const next = DEMO_USERS.find((row) => row.userId === event.target.value);
                setUserId(event.target.value);
                if (next?.role !== 'uniosun') setStateFilter('');
              }}>
              {DEMO_USERS.map((row) => (
                <option key={row.userId} value={row.userId}>
                  {row.name}
                </option>
              ))}
            </select>
          </label>
          {user.role === 'uniosun' ? (
            <label className={styles.field}>
              State
              <select
                className={styles.select}
                value={stateFilter}
                onChange={(event) => setStateFilter(event.target.value)}>
                <option value="">All states</option>
                {STATES.map((state) => (
                  <option key={state} value={state}>
                    {state}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
          <button className={styles.button} type="button" disabled={loading} onClick={() => void load(user, stateFilter)}>
            {loading ? 'Loading…' : 'Refresh'}
          </button>
        </div>
      </header>

      {error ? <div className={styles.error}>{error}</div> : null}

      {user.role !== 'field' ? (
        <>
          {user.role === 'uniosun' ? (
            <section className={styles.totals} aria-label="Alert tier totals">
              <div className={styles.total}>
                <div className={styles.totalLabel}>ALERT</div>
                <div className={styles.totalValue}>{totals.ALERT}</div>
              </div>
              <div className={styles.total}>
                <div className={styles.totalLabel}>WARNING</div>
                <div className={styles.totalValue}>{totals.WARNING}</div>
              </div>
              <div className={styles.total}>
                <div className={styles.totalLabel}>WATCH</div>
                <div className={styles.totalValue}>{totals.WATCH}</div>
              </div>
            </section>
          ) : null}

          <section className={styles.section}>
            <h2 className={styles.sectionTitle}>Alert feed ({alerts.length})</h2>
            {alerts.length === 0 ? (
              <p className={styles.empty}>{loading ? 'Loading alerts…' : 'No alerts for this view.'}</p>
            ) : (
              <div className={styles.list}>
                {alerts.map((alert) => (
                  <article key={alert.id} className={styles.alert}>
                    <span className={`${styles.tier} ${styles[`tier${alert.tier}`] ?? ''}`}>{alert.tier}</span>
                    <div className={styles.alertMain}>
                      <div className={styles.alertTitle}>
                        {alert.lga}, {alert.state}
                      </div>
                      <div className={styles.alertMeta}>
                        {alert.month} · {alert.n_records} records · mean risk {alert.mean_risk.toFixed(2)}
                      </div>
                    </div>
                    {alert.pyrethroid_resistance_flag ? (
                      <span className={styles.badge}>Pyrethroid resistance</span>
                    ) : (
                      <span />
                    )}
                  </article>
                ))}
              </div>
            )}
          </section>
        </>
      ) : (
        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Alerts</h2>
          <p className={styles.note}>Field accounts see their own records only. Alerts are for VECDIM and UNIOSUN.</p>
        </section>
      )}

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Records ({records.length})</h2>
        {records.length === 0 ? (
          <p className={styles.empty}>{loading ? 'Loading records…' : 'No records for this view.'}</p>
        ) : (
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Record</th>
                  <th>State</th>
                  <th>LGA</th>
                  <th>Ward</th>
                  <th>Date</th>
                  <th>Species</th>
                  <th>Mortality</th>
                  <th>Enrichment</th>
                </tr>
              </thead>
              <tbody>
                {records.map((row) => (
                  <tr key={row.record_id}>
                    <td>{row.record_id.slice(0, 8)}</td>
                    <td>{row.state}</td>
                    <td>{row.lga}</td>
                    <td>{row.ward}</td>
                    <td>{row.collection_date}</td>
                    <td>{row.species}</td>
                    <td>{row.mortality_pct === null ? '—' : `${row.mortality_pct.toFixed(1)}%`}</td>
                    <td>{row.enrichment_pending ? 'Pending' : 'Ready'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
