export type Role = 'field' | 'vecdim' | 'uniosun';

export interface DemoUser {
  userId: string;
  name: string;
  role: Role;
  state: string | null;
}

export const DEMO_USERS: DemoUser[] = [
  { userId: 'u_field_01', name: 'Field worker 1 (Lagos)', role: 'field', state: 'Lagos' },
  { userId: 'u_field_02', name: 'Field worker 2 (Kano)', role: 'field', state: 'Kano' },
  { userId: 'u_field_03', name: 'Field worker 3 (Osun)', role: 'field', state: 'Osun' },
  { userId: 'u_vecdim_lagos', name: 'VECDIM state user (Lagos)', role: 'vecdim', state: 'Lagos' },
  { userId: 'u_vecdim_kano', name: 'VECDIM state user (Kano)', role: 'vecdim', state: 'Kano' },
  { userId: 'u_vecdim_osun', name: 'VECDIM state user (Osun)', role: 'vecdim', state: 'Osun' },
  { userId: 'u_uniosun_01', name: 'UNIOSUN national user', role: 'uniosun', state: null },
];

export const STATES = ['Lagos', 'Kano', 'Osun'] as const;
