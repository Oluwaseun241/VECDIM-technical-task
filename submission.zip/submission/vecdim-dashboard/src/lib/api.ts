const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://127.0.0.1:3000/api/v1';

export interface AlertItem {
  id: string;
  state: string;
  lga: string;
  month: string;
  n_records: number;
  mean_risk: number;
  tier: string;
  pyrethroid_resistance_flag: boolean;
}

export interface RecordItem {
  record_id: string;
  state: string;
  lga: string;
  ward: string;
  collection_date: string;
  species: string;
  insecticide: string;
  n_exposed: number;
  n_dead: number;
  mortality_pct: number | null;
  enrichment_pending: boolean;
  submitted_by: string | null;
  received_at: string | null;
}

async function apiGet<T>(
  path: string,
  userId: string,
  query: Record<string, string | undefined> = {},
  signal?: AbortSignal,
): Promise<T> {
  const url = new URL(`${API_URL}${path}`);
  for (const [key, value] of Object.entries(query)) {
    if (value) url.searchParams.set(key, value);
  }
  const response = await fetch(url, {
    headers: { 'X-User-Id': userId },
    cache: 'no-store',
    signal,
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Request failed (${response.status})`);
  }
  return response.json() as Promise<T>;
}

export function fetchAlerts(userId: string, state?: string, signal?: AbortSignal) {
  return apiGet<AlertItem[]>('/alerts', userId, { state }, signal);
}

export function fetchRecords(userId: string, state?: string, signal?: AbortSignal) {
  return apiGet<RecordItem[]>('/records', userId, { state }, signal);
}
