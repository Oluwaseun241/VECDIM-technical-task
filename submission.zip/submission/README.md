# VECDIM — field capture, API, and role dashboard

Offline-first entomology capture (Expo), NestJS + PostgreSQL/PostGIS API with pack R validation, and a Next.js role dashboard. Built against the VECDIM candidate pack.

## Prerequisites

- Git
- Docker with Docker Compose
- Node.js **20 LTS**
- Expo Go on Android, or an Android emulator

Also needed here:

- Enough disk/network for the first pull of `postgis/postgis:16-3.5` and `rocker/r-ver:4.6.1` (R packages install on first `analysis:up`)

## Quick start

```bash
# From this repo root
cd vecdim-backend && npm install && cd ..
cd vecdim-dashboard && npm install && cd ..
cd vecdim-mobile && npm install && cd ..

# One command: Postgres (migrate + seed), R container, Nest API on :3000
# Run as your normal user — do not use sudo (breaks Podman / port 5432).
npm start
```

In two more terminals:

```bash
npm run dashboard   # http://127.0.0.1:3001
npm run mobile      # Expo; scan with Expo Go
```

API base: `http://127.0.0.1:3000/api/v1`. Auth is the `X-User-Id` header (demo users from the pack).

On a phone, leave `EXPO_PUBLIC_API_URL` unset so the app uses the Expo debugger host (your laptop’s LAN IP). Override only if needed — see `vecdim-mobile/.env.example`. Dashboard: copy `vecdim-dashboard/.env.example` to `.env.local` if you want a non-default API URL.

### Useful checks

```bash
npm run test:parity   # 1,525-row R parity → vecdim-backend/parity/parity-report.json
cd vecdim-backend && npm test && npm run test:api
cd vecdim-mobile && npm test
```

Seed is idempotent (`npm --prefix vecdim-backend run db:seed`). After seed, `GET /api/v1/alerts` with a UNIOSUN user returns **647** alerts (tier totals **86 / 135 / 426**).

## Demo users

| user_id | role | scope |
| --- | --- | --- |
| `u_field_01` / `02` / `03` | field | Lagos / Kano / Osun |
| `u_vecdim_lagos` / `_kano` / `_osun` | vecdim | one state |
| `u_uniosun_01` | uniosun | national |

Sign in on the phone with a field account; switch roles on the dashboard the same way.

## Repository layout

| Path | Role |
| --- | --- |
| `vecdim-mobile/` | Expo field app — form, GPS, drafts, sync queue |
| `vecdim-backend/` | Nest API, migrations, seed, R runner, parity CLI |
| `vecdim-dashboard/` | Next.js field / VECDIM / UNIOSUN views |
| `VECDIM_Candidate_Pack/` | Specs, sample data, R pipeline, answer keys |
| `scripts/dev-up.sh` | One-command backend stack (`npm start`) |

## Database schema

Versioned SQL under `vecdim-backend/db/migrations/`. The API connects as `vecdim_app` so **row-level security** applies.

```
users ──┬── field_records ──► lga_reference
        │         ▲ geom(Point,4326) + GiST
        └── sync_batches ── sync_batch_items ── validation_results
lga_reference ── alerts
               └─ risk_predictions (seeded / analysis)
analysis_runs (optional full pipeline runs)
```

- **users** — `field` | `vecdim` | `uniosun`; VECDIM/field carry a state.
- **field_records** — accepted forms only; `record_id` unique (phone UUID); PostGIS point; CHECK constraints mirror Block rules where PostgreSQL allows them.
- **sync_batches / sync_batch_items** — every upload attempt, including rejects and raw payload; each record uses a savepoint so one bad row leaves the rest of the batch intact.
- **validation_results** — Block/Warn flags per sync attempt.
- **alerts** — from `alerts.csv`; `tier` and `pyrethroid_resistance_flag` are separate columns.
- **lga_reference** — 15 LGA centroids for the 25 km warning and FKs.

Rejected records are **not** stored in `field_records`, so a corrected resubmit with the same `record_id` is a new insert.

## Design decisions

- **Device rules** live in TypeScript on the phone (fast, offline). **Server rules** call the pack’s `R/01_validate_and_clean.R` so the API stays byte-aligned with the answer key.
- Sync is automatic when NetInfo reports connectivity, with exponential backoff (cap 60s). Statuses: draft → pending_sync → synced / synced_with_flags / rejected.
- Dashboard stays thin: role switcher, alert feed by tier, records table, UNIOSUN totals. Maps, acknowledge, and DHIS2 export are left for later.

## Why this backend

**NestJS (TypeScript) + PostgreSQL/PostGIS + stock `rocker/r-ver` for R.**

1. **Existing R pipeline.** Today the API seeds `alerts.csv` / cleaned records into Postgres and serves them. Live validation shells into the pack script inside `vecdim-r`. A full re-run is `POST /api/v1/analysis/run` (UNIOSUN), which executes `R/run_all.R` in that container and refreshes outputs. Later, the same container (or a scheduled job) can replace the CSV seed path without changing the Nest surface.

2. **Future modelling.** New models (retraining, covariates, NTD) belong in the R (or Python) container: write predictions to tables such as `risk_predictions`, then expose read endpoints. The API stays a thin orchestrator and query layer; science stays versioned next to the pack scripts.

3. **Scalability.** Postgres holds the system of record with RLS for role scope. Nest scales horizontally behind a load balancer; sync batches are already partial-failure safe. At ~10k field workers the pressure points are connection pooling, batch size, and moving R validation to a queue/worker so request threads stay free — the schema already separates sync log from accepted rows for that split.

4. **Maintainability.** One language (TypeScript) across API tests and mobile domain code; SQL migrations are plain files; Compose brings up DB + R with no custom R image. A small team can run `npm start`, read `db/migrations/001_init.sql`, and extend endpoints without learning a second application framework.

**Trade-off:** calling R per sync batch is correct and parity-friendly; it is slower than a pure in-process port. For this programme’s volume and the need to trust the pack rules, correctness wins. A later worker queue keeps the same R entrypoint.

## Tests and parity

- Backend unit/e2e: `vecdim-backend` (`npm test`, `npm run test:api`, schema/seed/pipeline suites).
- Mobile: device rules + sync backoff (`vecdim-mobile` `npm test`).
- Parity artefact: `vecdim-backend/parity/parity-report.json` — **1525 rows, 0 differing records** vs `outputs/validation_flags_all.csv` (reference date `2026-10-08`).

## Known limitations

- NDVI / rainfall enrichment is accepted when missing (`enrichment_pending`); values are not filled from an external feed yet.
- Parity (`npm run test:parity`) freezes `future_date` at pack REF_DATE `2026-10-08`. Live sync uses the server’s calendar day via the same R `validate_records()`.
- Bonus endpoints from the contract (risk-points map layer, alert acknowledge, DHIS2 export) are not implemented.
- Auth is demo `X-User-Id` only (real OAuth/JWT is out of scope).
- `npm start` brings up the backend stack; dashboard and Expo are separate commands (documented above).
- Demo recording for the walkthrough is listed in the section below (file or link when ready).

## AI disclosure

**AI assistant:** Cursor (Composer) was used for scaffolding Nest/Expo/Next modules, drafting migrations and tests, I directed architecture choices (Nest + PostGIS + pack R on the server, device rules on the phone, Next for the dashboard), reviewed code against the pack specs, and ran the parity/API/mobile checks myself.

## Demo recording

Place a ≤3 minute walkthrough (offline capture → reconnect/sync → reject/fix/resubmit → dashboard) at:

- File: `./demo.mp4`
