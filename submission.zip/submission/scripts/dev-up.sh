#!/usr/bin/env bash
# One command to bring up the VECDIM backend stack for local demos.
# Starts Postgres, applies migrations, seeds demo data, starts the R container,
# then runs the Nest API in the foreground.
#
# Run as your normal user (no sudo). On this machine the stack uses rootless
# Podman; sudo switches to root Docker, fights over port 5432, and breaks migrate.
set -euo pipefail

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  echo "Do not run this script with sudo. Use: npm start   (or ./scripts/dev-up.sh)" >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BACKEND="$ROOT/vecdim-backend"

cd "$BACKEND"

echo "==> Database"
npm run db:setup
npm run db:seed

echo "==> R analysis container"
npm run analysis:up

echo "==> API on http://127.0.0.1:3000/api/v1"
echo "    Dashboard: cd vecdim-dashboard && npm run dev   (port 3001)"
echo "    Mobile:    cd vecdim-mobile && npx expo start"
npm run start:dev
